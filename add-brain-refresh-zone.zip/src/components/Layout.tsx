import { ReactNode, useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';

interface LayoutProps {
  children: ReactNode;
  title?: string;
  showBack?: boolean;
}

export default function Layout({ children, title, showBack = true }: LayoutProps) {
  const location = useLocation();
  const isHome = location.pathname === '/';
  const isBrain = location.pathname === '/brain';
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-cyan-50">
      {/* Top nav */}
      <nav className="sticky top-0 z-40 backdrop-blur-lg bg-white/70 border-b border-purple-100 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            {showBack && !isHome && !isBrain && (
              <Link
                to="/brain"
                className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 text-white flex items-center justify-center hover:scale-110 transition-transform shadow-lg"
                aria-label="Back to Brain Refresh"
              >
                ←
              </Link>
            )}
            <Link to="/" className="flex items-center gap-2 group">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 via-pink-500 to-yellow-400 flex items-center justify-center text-xl shadow-lg group-hover:scale-110 transition-transform">
                ✨
              </div>
              <div className="hidden sm:block">
                <div className="font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-pink-600 text-lg leading-tight">
                  Study Spark
                </div>
                <div className="text-xs text-gray-500 leading-tight">Smart Study Planner</div>
              </div>
            </Link>
          </div>
          
          {title && (
            <h1 className="text-lg md:text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-pink-600 hidden md:block">
              {title}
            </h1>
          )}
          
          <div className="flex items-center gap-2">
            <Link
              to="/stats"
              className="px-3 py-2 rounded-full bg-gradient-to-r from-yellow-400 to-orange-400 text-white font-semibold text-sm shadow-md hover:scale-105 transition-transform flex items-center gap-1"
            >
              🏆 Stats
            </Link>
          </div>
        </div>
      </nav>
      
      <main className="max-w-7xl mx-auto px-4 py-6">
        {children}
      </main>
    </div>
  );
}

// Confetti celebration component
export function Confetti({ trigger }: { trigger: number }) {
  const [particles, setParticles] = useState<Array<{ id: number; left: number; color: string; delay: number }>>([]);
  
  useEffect(() => {
    if (trigger === 0) return;
    
    // Check reduced motion preference
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReducedMotion) return;
    
    const colors = ['#a855f7', '#ec4899', '#facc15', '#06b6d4', '#10b981', '#f97316'];
    const newParticles = Array.from({ length: 50 }, (_, i) => ({
      id: Date.now() + i,
      left: Math.random() * 100,
      color: colors[Math.floor(Math.random() * colors.length)],
      delay: Math.random() * 0.5,
    }));
    
    setParticles(newParticles);
    
    const timer = setTimeout(() => setParticles([]), 3000);
    return () => clearTimeout(timer);
  }, [trigger]);
  
  return (
    <>
      {particles.map(p => (
        <div
          key={p.id}
          className="confetti-particle"
          style={{
            left: `${p.left}%`,
            backgroundColor: p.color,
            animation: `confetti 2s ease-in ${p.delay}s forwards`,
          }}
        />
      ))}
    </>
  );
}

// Result message based on score
export function getResultMessage(accuracy: number): { message: string; emoji: string; color: string } {
  if (accuracy === 100) return { message: 'GENIUS MODE ACTIVATED! You\'re on fire!', emoji: '🔥👑', color: 'from-yellow-400 to-orange-500' };
  if (accuracy >= 80) return { message: 'Amazing work! Your brain is getting stronger!', emoji: '💪⭐', color: 'from-purple-500 to-pink-500' };
  if (accuracy >= 50) return { message: 'Good effort! Keep practicing and level up!', emoji: '🌟📈', color: 'from-cyan-500 to-blue-500' };
  return { message: 'No worries! Every attempt is a chance to learn!', emoji: '🌱💚', color: 'from-green-500 to-teal-500' };
}

// Badge display component
export function BadgeIcon({ badgeId, size = 'md' }: { badgeId: string; size?: 'sm' | 'md' | 'lg' }) {
  const badges: Record<string, { icon: string; name: string }> = {
    first_victory: { icon: '🏅', name: 'First Victory' },
    quiz_champion: { icon: '🏆', name: 'Quiz Champion' },
    puzzle_master: { icon: '🧩', name: 'Puzzle Master' },
    memory_wizard: { icon: '🧙', name: 'Memory Wizard' },
    daily_hero: { icon: '⭐', name: 'Daily Hero' },
    streak_7: { icon: '🔥', name: '7-Day Streak' },
    xp_100: { icon: '💯', name: 'Century Club' },
    xp_500: { icon: '💎', name: 'XP Master' },
    xp_1000: { icon: '👑', name: 'Legend' },
    relaxation_guru: { icon: '🧘', name: 'Relaxation Guru' },
    all_rounder: { icon: '🌟', name: 'All Rounder' },
    perfectionist: { icon: '✨', name: 'Perfectionist' },
  };
  
  const badge = badges[badgeId];
  if (!badge) return null;
  
  const sizes = {
    sm: 'text-2xl',
    md: 'text-4xl',
    lg: 'text-6xl',
  };
  
  return (
    <div className="flex flex-col items-center gap-1 p-3 rounded-2xl bg-gradient-to-br from-yellow-100 to-orange-100 shadow-md hover:scale-110 transition-transform">
      <div className={sizes[size]}>{badge.icon}</div>
      <div className="text-xs font-semibold text-gray-700 text-center">{badge.name}</div>
    </div>
  );
}
