// Storage utilities for Brain Refresh Zone - simulates backend functionality

export interface UserStats {
  totalXP: number;
  totalActivitiesCompleted: number;
  highestQuizScore: number;
  highestQuizAccuracy: number;
  currentStreak: number;
  longestStreak: number;
  lastActivityDate: string;
  badges: string[];
  quizHistory: QuizAttempt[];
  gameHistory: GameResult[];
  dailyChallengeHistory: { [date: string]: boolean };
  achievements: { [key: string]: boolean };
}

export interface QuizAttempt {
  quizId: string;
  quizTitle: string;
  score: number;
  totalQuestions: number;
  accuracy: number;
  completedAt: string;
}

export interface GameResult {
  gameType: string;
  difficulty: string;
  score: number;
  durationSeconds: number;
  moves: number;
  completedAt: string;
}

const STORAGE_KEY = 'brainRefreshStats';

// Available badges
export const BADGES = {
  FIRST_VICTORY: { id: 'first_victory', name: 'First Victory', icon: '🏅', description: 'Completed your first activity' },
  QUIZ_CHAMPION: { id: 'quiz_champion', name: 'Quiz Champion', icon: '🏆', description: 'Scored 100% on a quiz' },
  PUZZLE_MASTER: { id: 'puzzle_master', name: 'Puzzle Master', icon: '🧩', description: 'Solved 10 puzzles' },
  MEMORY_WIZARD: { id: 'memory_wizard', name: 'Memory Wizard', icon: '🧙', description: 'Completed memory game on hard mode' },
  DAILY_HERO: { id: 'daily_hero', name: 'Daily Challenge Hero', icon: '⭐', description: 'Completed a daily challenge' },
  STREAK_7: { id: 'streak_7', name: 'Seven-Day Streak', icon: '🔥', description: '7-day activity streak' },
  XP_100: { id: 'xp_100', name: 'Century Club', icon: '💯', description: 'Earned 100 Brain XP' },
  XP_500: { id: 'xp_500', name: 'XP Master', icon: '💎', description: 'Earned 500 Brain XP' },
  XP_1000: { id: 'xp_1000', name: 'Legend', icon: '👑', description: 'Earned 1000 Brain XP' },
  RELAXATION_GURU: { id: 'relaxation_guru', name: 'Relaxation Guru', icon: '🧘', description: 'Completed 5 relaxation activities' },
  ALL_ROUNDER: { id: 'all_rounder', name: 'All Rounder', icon: '🌟', description: 'Tried all activity types' },
  PERFECTIONIST: { id: 'perfectionist', name: 'Perfectionist', icon: '✨', description: '5 perfect quiz scores' },
};

// Get default stats
const getDefaultStats = (): UserStats => ({
  totalXP: 0,
  totalActivitiesCompleted: 0,
  highestQuizScore: 0,
  highestQuizAccuracy: 0,
  currentStreak: 0,
  longestStreak: 0,
  lastActivityDate: '',
  badges: [],
  quizHistory: [],
  gameHistory: [],
  dailyChallengeHistory: {},
  achievements: {},
});

// Get current user stats
export const getStats = (): UserStats => {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) return getDefaultStats();
    return { ...getDefaultStats(), ...JSON.parse(stored) };
  } catch {
    return getDefaultStats();
  }
};

// Save stats
export const saveStats = (stats: UserStats): void => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(stats));
  } catch (e) {
    console.error('Failed to save stats', e);
  }
};

// Update streak
const updateStreak = (stats: UserStats): UserStats => {
  const today = new Date().toDateString();
  const lastActivity = stats.lastActivityDate;
  
  if (lastActivity === today) {
    return stats; // Already recorded today
  }
  
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  
  let newStreak = stats.currentStreak;
  if (lastActivity === yesterday.toDateString()) {
    newStreak = stats.currentStreak + 1;
  } else if (lastActivity !== today) {
    newStreak = 1;
  }
  
  return {
    ...stats,
    currentStreak: newStreak,
    longestStreak: Math.max(stats.longestStreak, newStreak),
    lastActivityDate: today,
  };
};

// Check and award badges
const checkBadges = (stats: UserStats): UserStats => {
  const newBadges = [...stats.badges];
  const newAchievements = { ...stats.achievements };
  
  // First victory
  if (stats.totalActivitiesCompleted >= 1 && !newAchievements[BADGES.FIRST_VICTORY.id]) {
    newBadges.push(BADGES.FIRST_VICTORY.id);
    newAchievements[BADGES.FIRST_VICTORY.id] = true;
  }
  
  // Quiz Champion
  if (stats.highestQuizAccuracy === 100 && !newAchievements[BADGES.QUIZ_CHAMPION.id]) {
    newBadges.push(BADGES.QUIZ_CHAMPION.id);
    newAchievements[BADGES.QUIZ_CHAMPION.id] = true;
  }
  
  // Puzzle Master
  const puzzleCount = stats.gameHistory.filter(g => g.gameType === 'puzzle').length;
  if (puzzleCount >= 10 && !newAchievements[BADGES.PUZZLE_MASTER.id]) {
    newBadges.push(BADGES.PUZZLE_MASTER.id);
    newAchievements[BADGES.PUZZLE_MASTER.id] = true;
  }
  
  // Memory Wizard
  const hardMemory = stats.gameHistory.find(g => g.gameType === 'memory' && g.difficulty === 'hard');
  if (hardMemory && !newAchievements[BADGES.MEMORY_WIZARD.id]) {
    newBadges.push(BADGES.MEMORY_WIZARD.id);
    newAchievements[BADGES.MEMORY_WIZARD.id] = true;
  }
  
  // Streak 7
  if (stats.currentStreak >= 7 && !newAchievements[BADGES.STREAK_7.id]) {
    newBadges.push(BADGES.STREAK_7.id);
    newAchievements[BADGES.STREAK_7.id] = true;
  }
  
  // XP milestones
  if (stats.totalXP >= 100 && !newAchievements[BADGES.XP_100.id]) {
    newBadges.push(BADGES.XP_100.id);
    newAchievements[BADGES.XP_100.id] = true;
  }
  if (stats.totalXP >= 500 && !newAchievements[BADGES.XP_500.id]) {
    newBadges.push(BADGES.XP_500.id);
    newAchievements[BADGES.XP_500.id] = true;
  }
  if (stats.totalXP >= 1000 && !newAchievements[BADGES.XP_1000.id]) {
    newBadges.push(BADGES.XP_1000.id);
    newAchievements[BADGES.XP_1000.id] = true;
  }
  
  // Relaxation Guru
  const relaxCount = stats.gameHistory.filter(g => g.gameType === 'relaxation').length;
  if (relaxCount >= 5 && !newAchievements[BADGES.RELAXATION_GURU.id]) {
    newBadges.push(BADGES.RELAXATION_GURU.id);
    newAchievements[BADGES.RELAXATION_GURU.id] = true;
  }
  
  // All Rounder - check if all activity types attempted
  const types = new Set(stats.gameHistory.map(g => g.gameType));
  if (types.size >= 4 && stats.quizHistory.length > 0 && !newAchievements[BADGES.ALL_ROUNDER.id]) {
    newBadges.push(BADGES.ALL_ROUNDER.id);
    newAchievements[BADGES.ALL_ROUNDER.id] = true;
  }
  
  // Perfectionist
  const perfectQuizzes = stats.quizHistory.filter(q => q.accuracy === 100).length;
  if (perfectQuizzes >= 5 && !newAchievements[BADGES.PERFECTIONIST.id]) {
    newBadges.push(BADGES.PERFECTIONIST.id);
    newAchievements[BADGES.PERFECTIONIST.id] = true;
  }
  
  return { ...stats, badges: newBadges, achievements: newAchievements };
};

// Add quiz attempt (simulates server validation)
export const recordQuizAttempt = (
  quizId: string,
  quizTitle: string,
  answers: number[],
  questions: { correctAnswer: number }[]
): { score: number; accuracy: number; xpEarned: number } => {
  // Server-side validation: verify answers against correct answers
  let correct = 0;
  answers.forEach((ans, idx) => {
    if (questions[idx] && ans === questions[idx].correctAnswer) {
      correct++;
    }
  });
  
  const total = questions.length;
  const accuracy = Math.round((correct / total) * 100);
  const xpEarned = Math.round(correct * 10 + (accuracy === 100 ? 20 : 0));
  
  const stats = getStats();
  const attempt: QuizAttempt = {
    quizId,
    quizTitle,
    score: correct,
    totalQuestions: total,
    accuracy,
    completedAt: new Date().toISOString(),
  };
  
  const updated = checkBadges(updateStreak({
    ...stats,
    totalXP: stats.totalXP + xpEarned,
    totalActivitiesCompleted: stats.totalActivitiesCompleted + 1,
    highestQuizScore: Math.max(stats.highestQuizScore, correct),
    highestQuizAccuracy: Math.max(stats.highestQuizAccuracy, accuracy),
    quizHistory: [attempt, ...stats.quizHistory].slice(0, 50),
  }));
  
  saveStats(updated);
  
  return { score: correct, accuracy, xpEarned };
};

// Record game result
export const recordGameResult = (
  gameType: string,
  difficulty: string,
  score: number,
  durationSeconds: number,
  moves: number = 0
): { xpEarned: number; newBadge?: string } => {
  const oldStats = getStats();
  
  // Validate and cap scores
  const validatedScore = Math.max(0, Math.min(score, 10000));
  const xpEarned = Math.round(validatedScore / 10) + 10;
  
  const result: GameResult = {
    gameType,
    difficulty,
    score: validatedScore,
    durationSeconds,
    moves,
    completedAt: new Date().toISOString(),
  };
  
  const updated = checkBadges(updateStreak({
    ...oldStats,
    totalXP: oldStats.totalXP + xpEarned,
    totalActivitiesCompleted: oldStats.totalActivitiesCompleted + 1,
    gameHistory: [result, ...oldStats.gameHistory].slice(0, 50),
  }));
  
  // Detect new badge
  const newBadges = updated.badges.filter(b => !oldStats.badges.includes(b));
  const newBadge = newBadges[0];
  
  saveStats(updated);
  
  return { xpEarned, newBadge };
};

// Record daily challenge completion
export const recordDailyChallenge = (
  _challengeId: string,
  isCorrect: boolean,
  rewardPoints: number
): { xpEarned: number; alreadyClaimed: boolean } => {
  const stats = getStats();
  const today = new Date().toDateString();
  
  // Prevent duplicate rewards
  if (stats.dailyChallengeHistory[today]) {
    return { xpEarned: 0, alreadyClaimed: true };
  }
  
  if (!isCorrect) {
    // Still mark as attempted to prevent re-trying for XP
    const updated = {
      ...stats,
      dailyChallengeHistory: { ...stats.dailyChallengeHistory, [today]: true },
    };
    saveStats(updated);
    return { xpEarned: 0, alreadyClaimed: false };
  }
  
  const xpEarned = rewardPoints;
  
  const updated = checkBadges(updateStreak({
    ...stats,
    totalXP: stats.totalXP + xpEarned,
    totalActivitiesCompleted: stats.totalActivitiesCompleted + 1,
    dailyChallengeHistory: { ...stats.dailyChallengeHistory, [today]: true },
    gameHistory: [{
      gameType: 'daily_challenge',
      difficulty: 'medium',
      score: xpEarned,
      durationSeconds: 0,
      moves: 0,
      completedAt: new Date().toISOString(),
    }, ...stats.gameHistory].slice(0, 50),
  }));
  
  saveStats(updated);
  
  return { xpEarned, alreadyClaimed: false };
};

// Check if daily challenge completed today
export const isDailyChallengeCompletedToday = (): boolean => {
  const stats = getStats();
  const today = new Date().toDateString();
  return !!stats.dailyChallengeHistory[today];
};

// Get today's challenge (consistent throughout the day)
export const getDailyChallengeIndex = (): number => {
  const today = new Date();
  const dayOfYear = Math.floor((today.getTime() - new Date(today.getFullYear(), 0, 0).getTime()) / 86400000);
  const year = today.getFullYear();
  return (dayOfYear + year) % 31; // We have 31 challenges
};

// Reset all stats (for development)
export const resetStats = (): void => {
  localStorage.removeItem(STORAGE_KEY);
};
