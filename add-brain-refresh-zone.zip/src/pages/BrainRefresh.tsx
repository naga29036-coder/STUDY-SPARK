import { Link } from 'react-router-dom';
import Layout from '../components/Layout';
import { getStats, BADGES } from '../utils/storage';
import { quizzes, motivationalMessages } from '../data/quizData';
import { useState, useEffect } from 'react';

export default function BrainRefresh() {
  const stats = getStats();
  const [messageIdx, setMessageIdx] = useState(0);
  
  useEffect(() => {
    const interval = setInterval(() => {
      setMessageIdx(i => (i + 1) % motivationalMessages.length);
    }, 4000);
    return () => clearInterval(interval);
  }, []);
  
  const activities = [
    {
      title: 'Knowledge Quizzes',
      description: 'Test your knowledge across multiple topics',
      icon: '🎯',
      color: 'from-purple-500 to-pink-500',
      link: null,
      badges: ['General', 'Science', 'Math', 'CS'],
    },
    {
      title: 'Daily Challenge',
      description: 'One new challenge every day!',
      icon: '⭐',
      color: 'from-yellow-400 to-orange-500',
      link: '/daily-challenge',
      badges: ['Daily'],
    },
    {
      title: 'Memory Game',
      description: 'Flip cards and find matching pairs',
      icon: '🧠',
      color: 'from-cyan-500 to-blue-500',
      link: '/memory',
      badges: ['Easy', 'Medium', 'Hard'],
    },
    {
      title: 'Logic Puzzles',
      description: 'Number sequences, patterns & more',
      icon: '🧩',
      color: 'from-emerald-500 to-teal-500',
      link: '/puzzles',
      badges: ['Sequences', 'Patterns'],
    },
    {
      title: 'Riddles & Words',
      description: 'Solve brain teasers and word games',
      icon: '💬',
      color: 'from-indigo-500 to-purple-500',
      link: '/riddles',
      badges: ['Scramble', 'Riddles'],
    },
    {
      title: 'Relaxation',
      description: 'Breathe, stretch, and reset',
      icon: '🧘',
      color: 'from-green-400 to-cyan-500',
      link: '/relaxation',
      badges: ['Breathing', 'Calm'],
    },
  ];
  
  return (
    <Layout title="Brain Refresh Zone 🧠">
      {/* Hero Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-purple-600 via-pink-500 to-yellow-400 p-8 md:p-12 mb-8 text-white shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-white/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-cyan-300/20 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2"></div>
        
        <div className="relative z-10 text-center">
          <div className="text-7xl mb-4 animate-float inline-block">🧠</div>
          <h1 className="text-4xl md:text-6xl font-black mb-3">
            Time to Refresh Your Brain!
          </h1>
          <p className="text-lg md:text-xl text-white/90 max-w-2xl mx-auto">
            Take a little break, play a little, come back stronger! 🚀
          </p>
          
          {/* Rotating motivational message */}
          <div className="mt-6 bg-white/20 backdrop-blur-md rounded-full px-6 py-3 inline-block">
            <p className="font-semibold transition-opacity">
              {motivationalMessages[messageIdx]}
            </p>
          </div>
        </div>
      </div>
      
      {/* Stats summary */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <div className="bg-gradient-to-br from-purple-500 to-pink-500 rounded-2xl p-5 text-white shadow-lg">
          <div className="text-3xl mb-1">⚡</div>
          <div className="text-3xl font-black">{stats.totalXP}</div>
          <div className="text-sm opacity-90">Brain XP</div>
        </div>
        <div className="bg-gradient-to-br from-cyan-500 to-blue-500 rounded-2xl p-5 text-white shadow-lg">
          <div className="text-3xl mb-1">🏆</div>
          <div className="text-3xl font-black">{stats.highestQuizAccuracy}%</div>
          <div className="text-sm opacity-90">Best Accuracy</div>
        </div>
        <div className="bg-gradient-to-br from-yellow-400 to-orange-500 rounded-2xl p-5 text-white shadow-lg">
          <div className="text-3xl mb-1">🔥</div>
          <div className="text-3xl font-black">{stats.currentStreak}</div>
          <div className="text-sm opacity-90">Day Streak</div>
        </div>
        <div className="bg-gradient-to-br from-green-400 to-teal-500 rounded-2xl p-5 text-white shadow-lg">
          <div className="text-3xl mb-1">🎖️</div>
          <div className="text-3xl font-black">{stats.badges.length}</div>
          <div className="text-sm opacity-90">Badges</div>
        </div>
      </div>
      
      {/* Recommended break duration */}
      <div className="bg-white rounded-3xl p-6 shadow-lg mb-8 border-2 border-purple-100">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="text-4xl">⏱️</div>
            <div>
              <div className="font-bold text-lg">Recommended Break: 5-10 minutes</div>
              <div className="text-sm text-gray-600">Short breaks boost focus & creativity!</div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-sm font-semibold text-gray-600">Today's Challenge:</span>
            <Link
              to="/daily-challenge"
              className="px-5 py-2 bg-gradient-to-r from-yellow-400 to-orange-500 text-white rounded-full font-bold shadow-md hover:scale-105 transition-transform"
            >
              Try Now ⭐
            </Link>
          </div>
        </div>
      </div>
      
      {/* Activity cards */}
      <div className="mb-8">
        <h2 className="text-3xl font-black mb-6 text-center text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-pink-600">
          Choose Your Activity 🎨
        </h2>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {activities.map((activity, i) => {
            const content = (
              <div 
                key={i}
                className={`relative overflow-hidden rounded-3xl bg-gradient-to-br ${activity.color} p-6 text-white shadow-xl hover:scale-105 transition-transform cursor-pointer group`}
              >
                <div className="absolute top-0 right-0 w-40 h-40 bg-white/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 group-hover:scale-150 transition-transform"></div>
                
                <div className="relative z-10">
                  <div className="text-6xl mb-4 group-hover:animate-float">{activity.icon}</div>
                  <h3 className="text-2xl font-black mb-2">{activity.title}</h3>
                  <p className="text-white/90 mb-4 text-sm">{activity.description}</p>
                  
                  <div className="flex flex-wrap gap-2">
                    {activity.badges.map(b => (
                      <span key={b} className="text-xs px-3 py-1 bg-white/20 backdrop-blur rounded-full font-semibold">
                        {b}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            );
            
            if (activity.title === 'Knowledge Quizzes') {
              return <QuizCarousel key={i} />;
            }
            
            if (activity.link) {
              return <Link key={i} to={activity.link}>{content}</Link>;
            }
            
            return content;
          })}
        </div>
      </div>
      
      {/* Badges display */}
      {stats.badges.length > 0 && (
        <div className="bg-white rounded-3xl p-6 shadow-lg mb-8">
          <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
            <span>🏅</span> Your Achievements
          </h2>
          <div className="grid grid-cols-3 md:grid-cols-6 gap-3">
            {stats.badges.slice(0, 12).map(badgeId => {
              const badge = Object.values(BADGES).find(b => b.id === badgeId);
              if (!badge) return null;
              return (
                <div key={badgeId} className="text-center p-3 rounded-2xl bg-gradient-to-br from-yellow-50 to-orange-50 hover:scale-110 transition-transform">
                  <div className="text-4xl mb-1">{badge.icon}</div>
                  <div className="text-xs font-semibold text-gray-700">{badge.name}</div>
                </div>
              );
            })}
          </div>
        </div>
      )}
      
      {/* Return to Dashboard */}
      <div className="text-center">
        <Link
          to="/"
          className="inline-block px-8 py-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold rounded-full shadow-xl hover:scale-105 transition-transform"
        >
          ← Back to Study Dashboard
        </Link>
      </div>
    </Layout>
  );
}

// Quiz carousel component
function QuizCarousel() {
  return (
    <div className="md:col-span-2 lg:col-span-3 rounded-3xl bg-gradient-to-br from-purple-500 via-pink-500 to-orange-400 p-6 shadow-xl">
      <div className="flex items-center gap-3 mb-4">
        <div className="text-5xl">🎯</div>
        <div>
          <h3 className="text-2xl font-black text-white">Knowledge Quizzes</h3>
          <p className="text-white/90 text-sm">Pick a topic and test your knowledge!</p>
        </div>
      </div>
      
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {quizzes.map(quiz => (
          <Link
            key={quiz.id}
            to={`/quiz/${quiz.id}`}
            className={`rounded-2xl bg-gradient-to-br ${quiz.color} p-4 text-white hover:scale-105 transition-transform shadow-lg`}
          >
            <div className="text-3xl mb-2">{quiz.icon}</div>
            <div className="font-bold text-sm">{quiz.title}</div>
            <div className="text-xs text-white/80 mt-1">{quiz.questions.length} questions</div>
          </Link>
        ))}
      </div>
    </div>
  );
}
