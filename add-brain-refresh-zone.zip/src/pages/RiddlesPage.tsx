import { useState } from 'react';
import Layout, { Confetti } from '../components/Layout';
import { riddles, wordGames } from '../data/quizData';
import { recordGameResult } from '../utils/storage';

type Tab = 'riddles' | 'scramble';

export default function RiddlesPage() {
  const [tab, setTab] = useState<Tab>('riddles');
  
  return (
    <Layout title="💬 Riddles & Words">
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <div className="rounded-3xl bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 p-8 text-white shadow-2xl mb-6">
          <h1 className="text-4xl font-black text-center mb-2">Riddles & Word Games</h1>
          <p className="text-center text-white/90">Exercise your brain with word challenges! 📚</p>
        </div>
        
        {/* Tabs */}
        <div className="flex gap-2 mb-6 bg-white p-2 rounded-2xl shadow-lg">
          <button
            onClick={() => setTab('riddles')}
            className={`flex-1 py-3 rounded-xl font-bold transition-all ${
              tab === 'riddles' 
                ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg' 
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            🧠 Riddles
          </button>
          <button
            onClick={() => setTab('scramble')}
            className={`flex-1 py-3 rounded-xl font-bold transition-all ${
              tab === 'scramble' 
                ? 'bg-gradient-to-r from-cyan-500 to-blue-500 text-white shadow-lg' 
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            🔤 Word Scramble
          </button>
        </div>
        
        {tab === 'riddles' ? <RiddlesGame /> : <ScrambleGame />}
      </div>
    </Layout>
  );
}

function RiddlesGame() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [userAnswer, setUserAnswer] = useState('');
  const [revealed, setRevealed] = useState(false);
  const [hintsUsed, setHintsUsed] = useState(0);
  const [solved, setSolved] = useState(0);
  const [confettiTrigger, setConfettiTrigger] = useState(0);
  const [feedback, setFeedback] = useState<'correct' | 'incorrect' | null>(null);
  
  const riddle = riddles[currentIndex % riddles.length];
  
  const handleSubmit = () => {
    const isCorrect = userAnswer.trim().toLowerCase() === riddle.answer.toLowerCase();
    setFeedback(isCorrect ? 'correct' : 'incorrect');
    
    if (isCorrect) {
      setSolved(s => s + 1);
      setConfettiTrigger(t => t + 1);
      recordGameResult('riddle', riddle.difficulty, 20, 0, 0);
    }
    
    setRevealed(true);
  };
  
  const nextRiddle = () => {
    setCurrentIndex(i => (i + 1) % riddles.length);
    setUserAnswer('');
    setRevealed(false);
    setHintsUsed(0);
    setFeedback(null);
  };
  
  const showHint = () => {
    setHintsUsed(h => h + 1);
  };
  
  const revealAnswer = () => {
    setRevealed(true);
  };
  
  return (
    <div>
      <Confetti trigger={confettiTrigger} />
      
      <div className="flex justify-center gap-3 mb-6">
        <div className="bg-white rounded-2xl px-5 py-3 shadow-lg">
          <div className="text-xs text-gray-500">Solved</div>
          <div className="text-2xl font-black text-purple-600">{solved}</div>
        </div>
      </div>
      
      <div className="bg-white rounded-3xl p-6 md:p-8 shadow-xl animate-slide-up">
        <div className="flex items-center justify-between mb-4">
          <div className="text-4xl">💭</div>
          <span className={`px-3 py-1 rounded-full text-xs font-bold ${
            riddle.difficulty === 'easy' ? 'bg-green-100 text-green-700' :
            riddle.difficulty === 'medium' ? 'bg-yellow-100 text-yellow-700' :
            'bg-red-100 text-red-700'
          }`}>
            {riddle.difficulty}
          </span>
        </div>
        
        <h2 className="text-xl md:text-2xl font-bold text-gray-800 mb-6 italic">
          "{riddle.riddle}"
        </h2>
        
        {/* Hints */}
        {hintsUsed > 0 && (
          <div className="mb-4 space-y-2">
            {riddle.hints.slice(0, hintsUsed).map((hint, i) => (
              <div key={i} className="p-3 bg-yellow-50 rounded-xl border border-yellow-200 text-sm animate-fade-in">
                💡 Hint {i + 1}: {hint}
              </div>
            ))}
          </div>
        )}
        
        {!revealed && (
          <>
            <input
              type="text"
              value={userAnswer}
              onChange={e => setUserAnswer(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && userAnswer.trim() && handleSubmit()}
              placeholder="Type your answer..."
              className="w-full p-4 rounded-2xl border-2 border-purple-200 focus:border-purple-500 outline-none mb-4"
            />
            
            <div className="flex flex-wrap gap-3">
              <button
                onClick={handleSubmit}
                disabled={!userAnswer.trim()}
                className="flex-1 py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold rounded-2xl hover:scale-105 transition-transform disabled:opacity-50"
              >
                ✓ Submit
              </button>
              {hintsUsed < riddle.hints.length && (
                <button
                  onClick={showHint}
                  className="px-5 py-3 bg-yellow-100 text-yellow-800 font-bold rounded-2xl hover:bg-yellow-200 transition-colors"
                >
                  💡 Hint ({hintsUsed}/{riddle.hints.length})
                </button>
              )}
              <button
                onClick={revealAnswer}
                className="px-5 py-3 bg-gray-100 text-gray-700 font-bold rounded-2xl hover:bg-gray-200 transition-colors"
              >
                👁️ Reveal
              </button>
            </div>
          </>
        )}
        
        {revealed && (
          <div className="animate-slide-up">
            {feedback === 'correct' && (
              <div className="p-4 rounded-2xl bg-green-50 border border-green-200 mb-4">
                <div className="font-bold text-green-800 text-lg">🎉 Correct!</div>
              </div>
            )}
            
            <div className="p-4 rounded-2xl bg-purple-50 border border-purple-200 mb-4">
              <div className="font-bold text-purple-900 mb-1">🎯 Answer</div>
              <div className="text-2xl font-black text-purple-700 capitalize">{riddle.answer}</div>
            </div>
            
            <div className="p-4 rounded-2xl bg-blue-50 border border-blue-200 mb-4">
              <div className="font-bold text-blue-900 mb-1">💡 Explanation</div>
              <p className="text-sm text-blue-800">{riddle.explanation}</p>
            </div>
            
            <button
              onClick={nextRiddle}
              className="w-full py-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold rounded-2xl hover:scale-105 transition-transform"
            >
              Next Riddle →
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

function ScrambleGame() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [userAnswer, setUserAnswer] = useState('');
  const [revealed, setRevealed] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [feedback, setFeedback] = useState<'correct' | 'incorrect' | null>(null);
  const [score, setScore] = useState(0);
  const [confettiTrigger, setConfettiTrigger] = useState(0);
  
  const game = wordGames[currentIndex % wordGames.length];
  
  const handleSubmit = () => {
    const isCorrect = userAnswer.trim().toUpperCase() === game.answer.toUpperCase();
    setFeedback(isCorrect ? 'correct' : 'incorrect');
    setRevealed(true);
    
    if (isCorrect) {
      setScore(s => s + 15);
      setConfettiTrigger(t => t + 1);
      recordGameResult('word_scramble', 'medium', 15, 0, 0);
    }
  };
  
  const nextGame = () => {
    setCurrentIndex(i => (i + 1) % wordGames.length);
    setUserAnswer('');
    setRevealed(false);
    setShowHint(false);
    setFeedback(null);
  };
  
  return (
    <div>
      <Confetti trigger={confettiTrigger} />
      
      <div className="flex justify-center gap-3 mb-6">
        <div className="bg-white rounded-2xl px-5 py-3 shadow-lg">
          <div className="text-xs text-gray-500">Score</div>
          <div className="text-2xl font-black text-cyan-600">{score}</div>
        </div>
      </div>
      
      <div className="bg-white rounded-3xl p-6 md:p-8 shadow-xl animate-slide-up">
        <div className="text-center mb-6">
          <div className="text-5xl mb-3">🔤</div>
          <div className="text-xs font-semibold text-cyan-600 mb-2">Category: {game.category}</div>
          <div className="text-4xl font-black tracking-widest bg-gradient-to-r from-cyan-500 to-blue-500 bg-clip-text text-transparent">
            {game.scrambled}
          </div>
          <p className="text-sm text-gray-600 mt-3">Unscramble the letters to form a word!</p>
        </div>
        
        {showHint && !revealed && (
          <div className="mb-4 p-3 bg-yellow-50 rounded-xl border border-yellow-200 text-sm animate-fade-in">
            💡 Hint: {game.hint}
          </div>
        )}
        
        {!revealed && (
          <>
            <input
              type="text"
              value={userAnswer}
              onChange={e => setUserAnswer(e.target.value.toUpperCase())}
              onKeyDown={e => e.key === 'Enter' && userAnswer.trim() && handleSubmit()}
              placeholder="Your answer..."
              className="w-full p-4 rounded-2xl border-2 border-cyan-200 focus:border-cyan-500 outline-none mb-4 text-center text-xl font-bold tracking-widest uppercase"
            />
            
            <div className="flex flex-wrap gap-3">
              <button
                onClick={handleSubmit}
                disabled={!userAnswer.trim()}
                className="flex-1 py-3 bg-gradient-to-r from-cyan-500 to-blue-500 text-white font-bold rounded-2xl hover:scale-105 transition-transform disabled:opacity-50"
              >
                ✓ Check
              </button>
              {!showHint && (
                <button
                  onClick={() => setShowHint(true)}
                  className="px-5 py-3 bg-yellow-100 text-yellow-800 font-bold rounded-2xl hover:bg-yellow-200"
                >
                  💡 Hint
                </button>
              )}
              <button
                onClick={() => setRevealed(true)}
                className="px-5 py-3 bg-gray-100 text-gray-700 font-bold rounded-2xl hover:bg-gray-200"
              >
                👁️ Reveal
              </button>
            </div>
          </>
        )}
        
        {revealed && (
          <div className="animate-slide-up">
            {feedback === 'correct' && (
              <div className="p-4 rounded-2xl bg-green-50 border border-green-200 mb-4 text-center">
                <div className="font-bold text-green-800 text-lg">🎉 Correct!</div>
              </div>
            )}
            
            <div className="p-4 rounded-2xl bg-cyan-50 border border-cyan-200 mb-4 text-center">
              <div className="font-bold text-cyan-900 mb-1">🎯 Answer</div>
              <div className="text-3xl font-black text-cyan-700 tracking-widest">{game.answer}</div>
              <div className="text-sm text-gray-600 mt-2">{game.hint}</div>
            </div>
            
            <button
              onClick={nextGame}
              className="w-full py-4 bg-gradient-to-r from-cyan-500 to-blue-500 text-white font-bold rounded-2xl hover:scale-105 transition-transform"
            >
              Next Word →
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
