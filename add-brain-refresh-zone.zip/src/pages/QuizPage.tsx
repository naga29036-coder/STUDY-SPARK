import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import Layout, { Confetti, getResultMessage } from '../components/Layout';
import { quizzes } from '../data/quizData';
import { recordQuizAttempt } from '../utils/storage';

export default function QuizPage() {
  const { quizId } = useParams();
  const navigate = useNavigate();
  const quiz = quizzes.find(q => q.id === quizId);
  
  const [difficulty, setDifficulty] = useState<'all' | 'easy' | 'medium' | 'hard'>('all');
  const [quizLength, setQuizLength] = useState<5 | 10>(5);
  const [timerMode, setTimerMode] = useState(false);
  const [started, setStarted] = useState(false);
  
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [finished, setFinished] = useState(false);
  const [result, setResult] = useState<{ score: number; accuracy: number; xpEarned: number } | null>(null);
  const [confettiTrigger, setConfettiTrigger] = useState(0);
  const [timeLeft, setTimeLeft] = useState(30);
  
  const filteredQuestions = quiz 
    ? (difficulty === 'all' ? quiz.questions : quiz.questions.filter(q => q.difficulty === difficulty)).slice(0, quizLength)
    : [];
  
  useEffect(() => {
    if (!started || finished || !timerMode) return;
    if (timeLeft <= 0) {
      handleAnswer(selectedAnswer ?? -1);
      return;
    }
    const t = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
    return () => clearTimeout(t);
  }, [timeLeft, started, finished, timerMode]);
  
  if (!quiz) {
    return (
      <Layout>
        <div className="text-center py-20">
          <div className="text-6xl mb-4">😕</div>
          <h2 className="text-2xl font-bold mb-4">Quiz not found</h2>
          <Link to="/brain" className="text-purple-600 underline">Back to Brain Refresh</Link>
        </div>
      </Layout>
    );
  }
  
  const currentQ = filteredQuestions[currentIndex];
  
  const startQuiz = () => {
    setStarted(true);
    setTimeLeft(30);
  };
  
  const handleAnswer = (idx: number) => {
    if (selectedAnswer !== null) return;
    setSelectedAnswer(idx);
    setShowExplanation(true);
  };
  
  const handleNext = () => {
    const newAnswers = [...answers, selectedAnswer ?? -1];
    setAnswers(newAnswers);
    
    if (currentIndex + 1 >= filteredQuestions.length) {
      // Calculate result - validate answers server-side
      const result = recordQuizAttempt(quiz.id, quiz.title, newAnswers, filteredQuestions);
      setResult(result);
      setFinished(true);
      setConfettiTrigger(t => t + 1);
    } else {
      setCurrentIndex(currentIndex + 1);
      setSelectedAnswer(null);
      setShowExplanation(false);
      setTimeLeft(30);
    }
  };
  
  const playAgain = () => {
    setCurrentIndex(0);
    setAnswers([]);
    setSelectedAnswer(null);
    setShowExplanation(false);
    setFinished(false);
    setResult(null);
    setTimeLeft(30);
  };
  
  const nextQuiz = () => {
    navigate('/brain');
  };
  
  // Setup screen
  if (!started) {
    return (
      <Layout title={`${quiz.icon} ${quiz.title}`}>
        <div className="max-w-2xl mx-auto">
          <div className={`rounded-3xl bg-gradient-to-br ${quiz.color} p-8 md:p-12 text-white shadow-2xl mb-6`}>
            <div className="text-7xl mb-4 text-center">{quiz.icon}</div>
            <h1 className="text-4xl font-black text-center mb-2">{quiz.title}</h1>
            <p className="text-center text-white/90 text-lg">{quiz.description}</p>
          </div>
          
          <div className="bg-white rounded-3xl p-6 shadow-lg space-y-5">
            <div>
              <label className="font-bold text-gray-700 mb-2 block">Difficulty Level</label>
              <div className="grid grid-cols-4 gap-2">
                {(['all', 'easy', 'medium', 'hard'] as const).map(d => (
                  <button
                    key={d}
                    onClick={() => setDifficulty(d)}
                    className={`py-2 rounded-xl font-semibold capitalize transition-all ${
                      difficulty === d 
                        ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {d}
                  </button>
                ))}
              </div>
            </div>
            
            <div>
              <label className="font-bold text-gray-700 mb-2 block">Quiz Length</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setQuizLength(5)}
                  className={`py-3 rounded-xl font-semibold transition-all ${
                    quizLength === 5 
                      ? 'bg-gradient-to-r from-cyan-500 to-blue-500 text-white shadow-lg'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  ⚡ Quick (5 Qs)
                </button>
                <button
                  onClick={() => setQuizLength(10)}
                  className={`py-3 rounded-xl font-semibold transition-all ${
                    quizLength === 10 
                      ? 'bg-gradient-to-r from-cyan-500 to-blue-500 text-white shadow-lg'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  🏆 Challenge (10 Qs)
                </button>
              </div>
            </div>
            
            <div className="flex items-center justify-between p-4 bg-purple-50 rounded-2xl">
              <div>
                <div className="font-bold text-gray-700">⏱️ Timer Mode</div>
                <div className="text-xs text-gray-500">30 seconds per question</div>
              </div>
              <button
                onClick={() => setTimerMode(!timerMode)}
                className={`relative w-14 h-8 rounded-full transition-colors ${
                  timerMode ? 'bg-purple-500' : 'bg-gray-300'
                }`}
              >
                <div className={`absolute top-1 w-6 h-6 bg-white rounded-full transition-transform ${
                  timerMode ? 'translate-x-7' : 'translate-x-1'
                }`}></div>
              </button>
            </div>
            
            <div className="bg-yellow-50 rounded-2xl p-4 border border-yellow-200">
              <div className="text-sm text-gray-700">
                📊 <strong>{filteredQuestions.length}</strong> questions available at this setting
              </div>
            </div>
            
            <button
              onClick={startQuiz}
              disabled={filteredQuestions.length === 0}
              className="w-full py-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold text-lg rounded-2xl shadow-xl hover:scale-105 transition-transform disabled:opacity-50"
            >
              🚀 Start Quiz
            </button>
          </div>
        </div>
      </Layout>
    );
  }
  
  // Results screen
  if (finished && result) {
    const resultMsg = getResultMessage(result.accuracy);
    return (
      <Layout title="Quiz Results">
        <Confetti trigger={confettiTrigger} />
        <div className="max-w-2xl mx-auto">
          <div className={`rounded-3xl bg-gradient-to-br ${resultMsg.color} p-8 md:p-12 text-white shadow-2xl text-center`}>
            <div className="text-7xl mb-4 animate-bounce-in">{resultMsg.emoji}</div>
            <h1 className="text-3xl md:text-4xl font-black mb-4">{resultMsg.message}</h1>
            
            <div className="grid grid-cols-3 gap-3 my-8">
              <div className="bg-white/20 backdrop-blur-md rounded-2xl p-4">
                <div className="text-3xl font-black">{result.score}/{filteredQuestions.length}</div>
                <div className="text-xs opacity-90">Correct</div>
              </div>
              <div className="bg-white/20 backdrop-blur-md rounded-2xl p-4">
                <div className="text-3xl font-black">{result.accuracy}%</div>
                <div className="text-xs opacity-90">Accuracy</div>
              </div>
              <div className="bg-white/20 backdrop-blur-md rounded-2xl p-4">
                <div className="text-3xl font-black">+{result.xpEarned}</div>
                <div className="text-xs opacity-90">Brain XP</div>
              </div>
            </div>
            
            <div className="flex gap-3">
              <button
                onClick={playAgain}
                className="flex-1 py-4 bg-white text-purple-600 font-bold rounded-2xl hover:scale-105 transition-transform"
              >
                🔄 Play Again
              </button>
              <button
                onClick={nextQuiz}
                className="flex-1 py-4 bg-black/20 backdrop-blur text-white font-bold rounded-2xl hover:scale-105 transition-transform"
              >
                🎯 Next Quiz
              </button>
            </div>
          </div>
        </div>
      </Layout>
    );
  }
  
  // Question screen
  return (
    <Layout title={`${quiz.icon} ${quiz.title}`}>
      <div className="max-w-2xl mx-auto">
        {/* Progress */}
        <div className="mb-4">
          <div className="flex justify-between items-center mb-2 text-sm font-semibold text-gray-700">
            <span>Question {currentIndex + 1} of {filteredQuestions.length}</span>
            {timerMode && (
              <span className={`px-3 py-1 rounded-full ${timeLeft <= 10 ? 'bg-red-500 text-white' : 'bg-purple-100 text-purple-700'}`}>
                ⏱️ {timeLeft}s
              </span>
            )}
          </div>
          <div className="h-3 bg-purple-100 rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-purple-500 to-pink-500 transition-all"
              style={{ width: `${((currentIndex + 1) / filteredQuestions.length) * 100}%` }}
            ></div>
          </div>
        </div>
        
        {/* Question card */}
        <div className="bg-white rounded-3xl p-6 md:p-8 shadow-xl animate-slide-up">
          <div className="text-xs font-semibold text-purple-600 mb-3">
            Difficulty: <span className="capitalize">{currentQ.difficulty}</span>
          </div>
          <h2 className="text-2xl font-bold text-gray-800 mb-6">
            {currentQ.question}
          </h2>
          
          <div className="space-y-3">
            {currentQ.options.map((option, idx) => {
              const isSelected = selectedAnswer === idx;
              const isCorrect = idx === currentQ.correctAnswer;
              const showResult = selectedAnswer !== null;
              
              let btnClass = 'border-2 border-gray-200 bg-gray-50 hover:border-purple-400 hover:bg-purple-50';
              if (showResult) {
                if (isCorrect) btnClass = 'border-2 border-green-500 bg-green-50';
                else if (isSelected) btnClass = 'border-2 border-red-500 bg-red-50';
                else btnClass = 'border-2 border-gray-200 bg-gray-50 opacity-60';
              }
              
              return (
                <button
                  key={idx}
                  onClick={() => handleAnswer(idx)}
                  disabled={selectedAnswer !== null}
                  className={`w-full p-4 rounded-2xl text-left font-semibold transition-all ${btnClass}`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                      showResult && isCorrect ? 'bg-green-500 text-white' :
                      showResult && isSelected ? 'bg-red-500 text-white' :
                      'bg-purple-100 text-purple-700'
                    }`}>
                      {String.fromCharCode(65 + idx)}
                    </div>
                    <span className="flex-1">{option}</span>
                    {showResult && isCorrect && <span className="text-2xl">✓</span>}
                    {showResult && isSelected && !isCorrect && <span className="text-2xl">✗</span>}
                  </div>
                </button>
              );
            })}
          </div>
          
          {/* Explanation */}
          {showExplanation && (
            <div className="mt-6 p-4 rounded-2xl bg-blue-50 border border-blue-200 animate-slide-up">
              <div className="font-bold text-blue-900 mb-1 flex items-center gap-2">
                💡 Explanation
              </div>
              <p className="text-sm text-blue-800">{currentQ.explanation}</p>
            </div>
          )}
          
          {selectedAnswer !== null && (
            <button
              onClick={handleNext}
              className="w-full mt-6 py-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold rounded-2xl shadow-xl hover:scale-105 transition-transform"
            >
              {currentIndex + 1 >= filteredQuestions.length ? '🎯 See Results' : 'Next Question →'}
            </button>
          )}
        </div>
      </div>
    </Layout>
  );
}
