import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Dashboard from './pages/Dashboard';
import BrainRefresh from './pages/BrainRefresh';
import QuizPage from './pages/QuizPage';
import MemoryGame from './pages/MemoryGame';
import PuzzlesPage from './pages/PuzzlesPage';
import RiddlesPage from './pages/RiddlesPage';
import Relaxation from './pages/Relaxation';
import StatsPage from './pages/StatsPage';
import DailyChallenge from './pages/DailyChallenge';

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/brain" element={<BrainRefresh />} />
        <Route path="/quiz/:quizId" element={<QuizPage />} />
        <Route path="/memory" element={<MemoryGame />} />
        <Route path="/puzzles" element={<PuzzlesPage />} />
        <Route path="/riddles" element={<RiddlesPage />} />
        <Route path="/relaxation" element={<Relaxation />} />
        <Route path="/stats" element={<StatsPage />} />
        <Route path="/daily-challenge" element={<DailyChallenge />} />
      </Routes>
    </BrowserRouter>
  );
}
