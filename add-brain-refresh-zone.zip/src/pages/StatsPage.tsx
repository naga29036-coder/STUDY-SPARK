import { useState } from 'react';
import Layout from '../components/Layout';
import { getStats, BADGES, resetStats } from '../utils/storage';

export default function StatsPage() {
  const stats = getStats();
  const [showReset, setShowReset] = useState(false);
  
  const handleReset = () => {
    resetStats();
    setShowReset(false);
    window.location.reload();
  };
  
  const totalBadges = Object.values(BADGES).length;
  
  return (
    <Layout title="🏆 Your Stats">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="rounded-3xl bg-gradient-to-br from-yellow-400 via-orange-500 to-pink-500 p-8 text-white shadow-2xl mb-6">
          <h1 className="text-4xl font-black text-center mb-2">Your Progress</h1>
          <p className="text-center text-white/90">Every achievement counts! 🌟</p>
        </div>
        
        {/* Main stats */}
        <div className="grid md:grid-cols-3 gap-4 mb-6">
          <div className="bg-white rounded-3xl p-6 shadow-xl text-center">
            <div className="text-5xl mb-2">⚡</div>
            <div className="text-5xl font-black bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              {stats.totalXP}
            </div>
            <div className="text-sm text-gray-600 mt-2 font-semibold">Total Brain XP</div>
          </div>
          
          <div className="bg-white rounded-3xl p-6 shadow-xl text-center">
            <div className="text-5xl mb-2">🎯</div>
            <div className="text-5xl font-black bg-gradient-to-r from-cyan-500 to-blue-500 bg-clip-text text-transparent">
              {stats.totalActivitiesCompleted}
            </div>
            <div className="text-sm text-gray-600 mt-2 font-semibold">Activities Completed</div>
          </div>
          
          <div className="bg-white rounded-3xl p-6 shadow-xl text-center">
            <div className="text-5xl mb-2">🔥</div>
            <div className="text-5xl font-black bg-gradient-to-r from-orange-500 to-red-500 bg-clip-text text-transparent">
              {stats.currentStreak}
            </div>
            <div className="text-sm text-gray-600 mt-2 font-semibold">Current Streak</div>
            <div className="text-xs text-gray-500 mt-1">Longest: {stats.longestStreak}</div>
          </div>
        </div>
        
        {/* Quiz stats */}
        <div className="bg-gradient-to-br from-purple-500 to-pink-500 rounded-3xl p-6 text-white shadow-xl mb-6">
          <h2 className="text-2xl font-black mb-4 flex items-center gap-2">
            <span>📊</span> Quiz Performance
          </h2>
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-white/20 backdrop-blur rounded-2xl p-4">
              <div className="text-3xl font-black">{stats.highestQuizScore}</div>
              <div className="text-xs opacity-90">Best Score</div>
            </div>
            <div className="bg-white/20 backdrop-blur rounded-2xl p-4">
              <div className="text-3xl font-black">{stats.highestQuizAccuracy}%</div>
              <div className="text-xs opacity-90">Best Accuracy</div>
            </div>
          </div>
        </div>
        
        {/* Badges */}
        <div className="bg-white rounded-3xl p-6 shadow-xl mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-black flex items-center gap-2">
              <span>🏅</span> Badges ({stats.badges.length}/{totalBadges})
            </h2>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {Object.values(BADGES).map(badge => {
              const earned = stats.badges.includes(badge.id);
              return (
                <div 
                  key={badge.id}
                  className={`rounded-2xl p-4 text-center transition-all ${
                    earned 
                      ? 'bg-gradient-to-br from-yellow-100 to-orange-100 shadow-md hover:scale-105' 
                      : 'bg-gray-100 opacity-50'
                  }`}
                >
                  <div className="text-5xl mb-2">{badge.icon}</div>
                  <div className="font-bold text-sm text-gray-800">{badge.name}</div>
                  <div className="text-xs text-gray-600 mt-1">{badge.description}</div>
                  {earned && <div className="text-xs text-green-600 font-bold mt-2">✓ Earned</div>}
                </div>
              );
            })}
          </div>
        </div>
        
        {/* Recent Activity */}
        <div className="grid md:grid-cols-2 gap-4 mb-6">
          <div className="bg-white rounded-3xl p-6 shadow-xl">
            <h2 className="text-xl font-black mb-4 flex items-center gap-2">
              <span>📝</span> Recent Quizzes
            </h2>
            {stats.quizHistory.length === 0 ? (
              <p className="text-gray-500 text-center py-6">No quizzes taken yet. Try one!</p>
            ) : (
              <div className="space-y-2 max-h-80 overflow-y-auto">
                {stats.quizHistory.slice(0, 10).map((q, i) => (
                  <div key={i} className="flex items-center justify-between p-3 bg-purple-50 rounded-xl">
                    <div>
                      <div className="font-semibold text-sm">{q.quizTitle}</div>
                      <div className="text-xs text-gray-500">
                        {new Date(q.completedAt).toLocaleDateString()}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-purple-600">{q.score}/{q.totalQuestions}</div>
                      <div className="text-xs text-gray-500">{q.accuracy}%</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
          
          <div className="bg-white rounded-3xl p-6 shadow-xl">
            <h2 className="text-xl font-black mb-4 flex items-center gap-2">
              <span>🎮</span> Recent Games
            </h2>
            {stats.gameHistory.length === 0 ? (
              <p className="text-gray-500 text-center py-6">No games played yet. Try one!</p>
            ) : (
              <div className="space-y-2 max-h-80 overflow-y-auto">
                {stats.gameHistory.slice(0, 10).map((g, i) => (
                  <div key={i} className="flex items-center justify-between p-3 bg-cyan-50 rounded-xl">
                    <div>
                      <div className="font-semibold text-sm capitalize">{g.gameType.replace('_', ' ')}</div>
                      <div className="text-xs text-gray-500 capitalize">{g.difficulty}</div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-cyan-600">+{g.score}</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
        
        {/* Motivational */}
        <div className="bg-gradient-to-r from-purple-600 via-pink-500 to-orange-400 rounded-3xl p-6 text-white text-center shadow-xl mb-6">
          <div className="text-4xl mb-2">🌟</div>
          <p className="text-lg font-bold">
            {stats.totalXP === 0 
              ? "Start your journey! Every step counts. 🚀" 
              : stats.totalXP < 100 
              ? "Great start! Keep the momentum going! 💪"
              : stats.totalXP < 500
              ? "You're on fire! Your brain is getting stronger! 🔥"
              : "Legendary status! You're an inspiration! 👑"}
          </p>
        </div>
        
        {/* Reset button */}
        <div className="text-center">
          <button
            onClick={() => setShowReset(true)}
            className="text-sm text-gray-400 hover:text-red-500 underline"
          >
            Reset all progress
          </button>
        </div>
        
        {showReset && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
            <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl">
              <h3 className="text-2xl font-black mb-4">Reset Progress?</h3>
              <p className="text-gray-600 mb-6">
                This will permanently delete all your XP, badges, and history. This cannot be undone.
              </p>
              <div className="flex gap-3">
                <button
                  onClick={() => setShowReset(false)}
                  className="flex-1 py-3 bg-gray-100 rounded-xl font-bold"
                >
                  Cancel
                </button>
                <button
                  onClick={handleReset}
                  className="flex-1 py-3 bg-red-500 text-white rounded-xl font-bold"
                >
                  Reset
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
}
