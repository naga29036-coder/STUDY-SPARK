import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Layout from '../components/Layout';
import { getStats } from '../utils/storage';

export default function Dashboard() {
  const [pomodoroTime, setPomodoroTime] = useState(25 * 60);
  const [isRunning, setIsRunning] = useState(false);
  const [showBreakPrompt, setShowBreakPrompt] = useState(false);
  const [sessions, setSessions] = useState(0);
  const stats = getStats();
  
  useEffect(() => {
    if (!isRunning || pomodoroTime <= 0) return;
    const interval = setInterval(() => {
      setPomodoroTime(t => {
        if (t <= 1) {
          setIsRunning(false);
          setSessions(s => s + 1);
          setShowBreakPrompt(true);
          return 0;
        }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [isRunning, pomodoroTime]);
  
  const formatTime = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
  };
  
  const startTimer = () => setIsRunning(true);
  const pauseTimer = () => setIsRunning(false);
  const resetTimer = () => { setPomodoroTime(25 * 60); setIsRunning(false); };
  
  const tasks = [
    { id: 1, title: 'Study Mathematics - Chapter 5', duration: '1 hour', priority: 'high', done: false },
    { id: 2, title: 'Read Computer Science notes', duration: '45 min', priority: 'medium', done: false },
    { id: 3, title: 'Practice Python problems', duration: '30 min', priority: 'high', done: false },
    { id: 4, title: 'Review English vocabulary', duration: '20 min', priority: 'low', done: false },
  ];
  
  return (
    <Layout showBack={false}>
      {/* Hero banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-purple-600 via-pink-500 to-orange-400 p-8 mb-6 text-white shadow-2xl">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-yellow-300/20 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2"></div>
        
        <div className="relative z-10">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-3xl">📚</span>
            <span className="text-sm font-semibold bg-white/20 px-3 py-1 rounded-full">Study Dashboard</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-black mb-3">Welcome back! 👋</h1>
          <p className="text-lg md:text-xl text-white/90 mb-6">Ready to crush your study goals today?</p>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div className="bg-white/20 backdrop-blur-md rounded-2xl p-4">
              <div className="text-3xl font-black">{stats.totalXP}</div>
              <div className="text-xs text-white/80">Brain XP</div>
            </div>
            <div className="bg-white/20 backdrop-blur-md rounded-2xl p-4">
              <div className="text-3xl font-black">{stats.currentStreak}🔥</div>
              <div className="text-xs text-white/80">Day Streak</div>
            </div>
            <div className="bg-white/20 backdrop-blur-md rounded-2xl p-4">
              <div className="text-3xl font-black">{stats.badges.length}</div>
              <div className="text-xs text-white/80">Badges</div>
            </div>
            <div className="bg-white/20 backdrop-blur-md rounded-2xl p-4">
              <div className="text-3xl font-black">{stats.totalActivitiesCompleted}</div>
              <div className="text-xs text-white/80">Activities</div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Brain Refresh CTA */}
      <Link 
        to="/brain"
        className="block mb-6 rounded-3xl bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 p-1 shadow-2xl hover:scale-[1.02] transition-transform group"
      >
        <div className="rounded-3xl bg-white p-6 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="text-6xl animate-float">🧠</div>
            <div>
              <h2 className="text-2xl md:text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-pink-600">
                Brain Refresh Zone
              </h2>
              <p className="text-gray-600 mt-1">Take a break, play a little, come back stronger! 🎮</p>
            </div>
          </div>
          <div className="text-3xl group-hover:translate-x-2 transition-transform">→</div>
        </div>
      </Link>
      
      <div className="grid md:grid-cols-3 gap-6">
        {/* Tasks */}
        <div className="md:col-span-2 bg-white rounded-3xl p-6 shadow-lg">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <span>📋</span> Today's Tasks
            </h2>
            <button className="text-sm px-4 py-2 bg-purple-100 text-purple-700 rounded-full font-semibold hover:bg-purple-200">
              + Add Task
            </button>
          </div>
          
          <div className="space-y-3">
            {tasks.map(task => (
              <div key={task.id} className="flex items-center gap-4 p-4 rounded-2xl bg-gradient-to-r from-purple-50 to-pink-50 hover:shadow-md transition-shadow">
                <input 
                  type="checkbox" 
                  className="w-6 h-6 accent-purple-500 cursor-pointer"
                />
                <div className="flex-1">
                  <div className="font-semibold text-gray-800">{task.title}</div>
                  <div className="text-sm text-gray-500">⏱️ {task.duration}</div>
                </div>
                <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                  task.priority === 'high' ? 'bg-red-100 text-red-700' :
                  task.priority === 'medium' ? 'bg-yellow-100 text-yellow-700' :
                  'bg-green-100 text-green-700'
                }`}>
                  {task.priority}
                </span>
              </div>
            ))}
          </div>
        </div>
        
        {/* Pomodoro Timer */}
        <div className="bg-gradient-to-br from-purple-500 to-pink-500 rounded-3xl p-6 text-white shadow-xl">
          <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
            <span>🍅</span> Focus Timer
          </h2>
          
          <div className="bg-white/20 backdrop-blur-md rounded-2xl p-8 mb-4 text-center">
            <div className="text-6xl font-black mb-2 font-mono">
              {formatTime(pomodoroTime)}
            </div>
            <div className="text-sm text-white/80">
              {isRunning ? 'Focus mode ON' : pomodoroTime === 0 ? 'Session complete!' : 'Ready to focus?'}
            </div>
          </div>
          
          <div className="grid grid-cols-3 gap-2">
            <button 
              onClick={startTimer}
              disabled={isRunning}
              className="bg-white text-purple-600 font-bold py-3 rounded-xl hover:scale-105 transition-transform disabled:opacity-50"
            >
              ▶️ Start
            </button>
            <button 
              onClick={pauseTimer}
              disabled={!isRunning}
              className="bg-white/20 backdrop-blur font-bold py-3 rounded-xl hover:scale-105 transition-transform disabled:opacity-50"
            >
              ⏸️ Pause
            </button>
            <button 
              onClick={resetTimer}
              className="bg-white/20 backdrop-blur font-bold py-3 rounded-xl hover:scale-105 transition-transform"
            >
              🔄 Reset
            </button>
          </div>
          
          <div className="mt-4 text-center text-sm text-white/80">
            Sessions completed: <strong>{sessions}</strong>
          </div>
        </div>
      </div>
      
      {/* Break Prompt Modal */}
      {showBreakPrompt && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-3xl p-8 max-w-md w-full shadow-2xl animate-bounce-in">
            <div className="text-6xl text-center mb-4 animate-float">🎉</div>
            <h2 className="text-3xl font-black text-center bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent mb-2">
              Focus Complete!
            </h2>
            <p className="text-center text-gray-600 mb-6">
              Great job! Want to refresh your brain? 🧠
            </p>
            
            <div className="space-y-3">
              <Link 
                to="/brain" 
                onClick={() => setShowBreakPrompt(false)}
                className="block w-full p-4 rounded-2xl bg-gradient-to-r from-purple-500 to-pink-500 text-white font-bold text-center hover:scale-105 transition-transform"
              >
                🎮 Play a 2-minute quiz
              </Link>
              <Link 
                to="/puzzles" 
                onClick={() => setShowBreakPrompt(false)}
                className="block w-full p-4 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-500 text-white font-bold text-center hover:scale-105 transition-transform"
              >
                🧩 Try a quick puzzle
              </Link>
              <Link 
                to="/relaxation" 
                onClick={() => setShowBreakPrompt(false)}
                className="block w-full p-4 rounded-2xl bg-gradient-to-r from-green-400 to-teal-500 text-white font-bold text-center hover:scale-105 transition-transform"
              >
                🧘 Take a breathing break
              </Link>
              <button 
                onClick={() => { setShowBreakPrompt(false); resetTimer(); }}
                className="block w-full p-4 rounded-2xl bg-gray-100 text-gray-700 font-bold text-center hover:bg-gray-200 transition-colors"
              >
                📚 Continue studying
              </button>
            </div>
          </div>
        </div>
      )}
    </Layout>
  );
}
