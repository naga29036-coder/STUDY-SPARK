import { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import { recordGameResult } from '../utils/storage';
import { affirmations } from '../data/quizData';

type Activity = 'menu' | 'breathing' | 'guided' | 'stretch' | 'eyerest' | 'affirmation' | 'gratitude';

export default function Relaxation() {
  const [activity, setActivity] = useState<Activity>('menu');
  const [completed, setCompleted] = useState(0);
  
  const completeActivity = () => {
    setCompleted(c => c + 1);
    recordGameResult('relaxation', 'calm', 10, 60, 0);
  };
  
  return (
    <Layout title="🧘 Relaxation">
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <div className="rounded-3xl bg-gradient-to-br from-green-300 via-cyan-400 to-blue-400 p-8 text-white shadow-2xl mb-6">
          <h1 className="text-4xl font-black text-center mb-2">Relaxation Corner</h1>
          <p className="text-center text-white/90">Take a moment to breathe, stretch, and reset 🌸</p>
        </div>
        
        {activity === 'menu' ? (
          <RelaxationMenu onSelect={setActivity} completed={completed} />
        ) : (
          <div>
            <button
              onClick={() => setActivity('menu')}
              className="mb-4 px-4 py-2 bg-white rounded-full shadow hover:scale-105 transition-transform font-semibold text-gray-700"
            >
              ← Back to Menu
            </button>
            
            {activity === 'breathing' && <BreathingExercise onComplete={completeActivity} />}
            {activity === 'guided' && <GuidedRelaxation onComplete={completeActivity} />}
            {activity === 'stretch' && <StretchReminders onComplete={completeActivity} />}
            {activity === 'eyerest' && <EyeRest onComplete={completeActivity} />}
            {activity === 'affirmation' && <AffirmationCards onComplete={completeActivity} />}
            {activity === 'gratitude' && <GratitudeReflection onComplete={completeActivity} />}
          </div>
        )}
      </div>
    </Layout>
  );
}

function RelaxationMenu({ onSelect, completed }: { onSelect: (a: Activity) => void; completed: number }) {
  const activities = [
    { id: 'breathing' as Activity, icon: '🫁', title: '1-Minute Breathing', desc: 'Calm breathing circle', color: 'from-blue-400 to-cyan-400', duration: '1 min' },
    { id: 'guided' as Activity, icon: '🌿', title: '2-Minute Relaxation', desc: 'Guided relaxation', color: 'from-green-400 to-emerald-400', duration: '2 min' },
    { id: 'stretch' as Activity, icon: '🤸', title: 'Stretch Break', desc: 'Gentle stretches', color: 'from-purple-400 to-pink-400', duration: '3 min' },
    { id: 'eyerest' as Activity, icon: '👁️', title: 'Eye Rest', desc: '20-20-20 rule', color: 'from-indigo-400 to-purple-400', duration: '1 min' },
    { id: 'affirmation' as Activity, icon: '💫', title: 'Positive Affirmations', desc: 'Uplifting thoughts', color: 'from-yellow-400 to-orange-400', duration: '1 min' },
    { id: 'gratitude' as Activity, icon: '🙏', title: 'Gratitude Reflection', desc: 'Short gratitude moment', color: 'from-pink-400 to-rose-400', duration: '2 min' },
  ];
  
  return (
    <>
      {completed > 0 && (
        <div className="mb-6 bg-gradient-to-r from-green-400 to-emerald-500 text-white rounded-2xl p-4 text-center shadow-lg animate-bounce-in">
          <div className="font-bold">🌟 You've completed {completed} relaxation activit{completed === 1 ? 'y' : 'ies'}! Feeling refreshed?</div>
        </div>
      )}
      
      <div className="bg-white rounded-2xl p-4 shadow-lg mb-6 text-sm text-gray-600">
        💡 <strong>Tip:</strong> Short breaks improve focus and reduce stress. These activities are optional - choose what feels right for you.
      </div>
      
      <div className="grid md:grid-cols-2 gap-4">
        {activities.map(act => (
          <button
            key={act.id}
            onClick={() => onSelect(act.id)}
            className={`rounded-3xl bg-gradient-to-br ${act.color} p-6 text-white shadow-xl hover:scale-105 transition-transform text-left`}
          >
            <div className="text-5xl mb-3">{act.icon}</div>
            <h3 className="text-xl font-black mb-1">{act.title}</h3>
            <p className="text-white/90 text-sm mb-2">{act.desc}</p>
            <div className="text-xs bg-white/20 inline-block px-3 py-1 rounded-full">⏱️ {act.duration}</div>
          </button>
        ))}
      </div>
    </>
  );
}

function BreathingExercise({ onComplete }: { onComplete: () => void }) {
  const [phase, setPhase] = useState<'inhale' | 'hold' | 'exhale'>('inhale');
  const [secondsLeft, setSecondsLeft] = useState(60);
  const [done, setDone] = useState(false);
  
  useEffect(() => {
    if (done) return;
    
    let elapsed = 0;
    const interval = setInterval(() => {
      elapsed++;
      setSecondsLeft(s => {
        if (s <= 1) {
          setDone(true);
          onComplete();
          return 0;
        }
        return s - 1;
      });
      
      const cycleTime = elapsed % 14;
      if (cycleTime < 4) setPhase('inhale');
      else if (cycleTime < 8) setPhase('hold');
      else setPhase('exhale');
    }, 1000);
    
    return () => clearInterval(interval);
  }, [done, onComplete]);
  
  const phaseText = {
    inhale: 'Breathe In',
    hold: 'Hold',
    exhale: 'Breathe Out',
  };
  
  const phaseColor = {
    inhale: 'from-blue-400 to-cyan-400',
    hold: 'from-purple-400 to-pink-400',
    exhale: 'from-green-400 to-teal-400',
  };
  
  return (
    <div className="bg-white rounded-3xl p-8 shadow-xl text-center">
      <h2 className="text-3xl font-black mb-6 text-gray-800">1-Minute Breathing</h2>
      
      <div className="flex justify-center mb-8">
        <div className={`relative w-64 h-64 rounded-full bg-gradient-to-br ${phaseColor[phase]} flex items-center justify-center shadow-2xl ${
          phase === 'inhale' ? 'animate-breathe' : phase === 'exhale' ? 'animate-breathe' : ''
        }`}>
          <div className="text-center text-white">
            <div className="text-3xl font-black">{phaseText[phase]}</div>
            <div className="text-6xl mt-2">{phase === 'inhale' ? '🫁' : phase === 'hold' ? '💨' : '🌬️'}</div>
          </div>
        </div>
      </div>
      
      <div className="text-4xl font-black text-gray-800 mb-4">{secondsLeft}s</div>
      <p className="text-gray-600">Follow the circle. Breathe in for 4, hold for 4, out for 6.</p>
      
      {done && (
        <div className="mt-6 p-4 bg-green-50 rounded-2xl border border-green-200 animate-bounce-in">
          <div className="font-bold text-green-800">✨ Great job! You feel calmer, don't you?</div>
        </div>
      )}
    </div>
  );
}

function GuidedRelaxation({ onComplete }: { onComplete: () => void }) {
  const [step, setStep] = useState(0);
  const [done, setDone] = useState(false);
  
  const steps = [
    { text: 'Find a comfortable position. Close your eyes if you can. 🧘', icon: '🌱' },
    { text: 'Take a deep breath in through your nose... 🫁', icon: '💨' },
    { text: 'Slowly exhale through your mouth... 🌬️', icon: '✨' },
    { text: 'Relax your shoulders. Let go of any tension. 💆', icon: '🌸' },
    { text: 'Feel your body becoming lighter. 🎈', icon: '☁️' },
    { text: 'Notice the sounds around you, without judging them. 🎵', icon: '🌿' },
    { text: 'You are calm. You are safe. You are doing great. 💫', icon: '🌟' },
    { text: 'Slowly bring your awareness back. Open your eyes when ready. 👁️', icon: '🌞' },
  ];
  
  useEffect(() => {
    if (step >= steps.length) {
      setDone(true);
      onComplete();
      return;
    }
    const t = setTimeout(() => setStep(s => s + 1), 15000);
    return () => clearTimeout(t);
  }, [step, onComplete, steps.length]);
  
  return (
    <div className="bg-white rounded-3xl p-8 shadow-xl text-center">
      <h2 className="text-3xl font-black mb-6 text-gray-800">2-Minute Guided Relaxation</h2>
      
      {!done ? (
        <div className="min-h-[200px] flex flex-col items-center justify-center animate-fade-in">
          <div className="text-8xl mb-6 animate-float">{steps[step]?.icon}</div>
          <p className="text-xl text-gray-700 font-semibold max-w-md">
            {steps[step]?.text}
          </p>
          <div className="mt-6 text-sm text-gray-500">
            Step {step + 1} of {steps.length}
          </div>
        </div>
      ) : (
        <div className="animate-bounce-in">
          <div className="text-7xl mb-4">🌸</div>
          <h3 className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-green-500 to-teal-500">
            Beautiful! You completed the relaxation.
          </h3>
          <p className="text-gray-600 mt-3">Take this calm feeling with you.</p>
        </div>
      )}
    </div>
  );
}

function StretchReminders({ onComplete }: { onComplete: () => void }) {
  const stretches = [
    { name: 'Neck Roll', desc: 'Slowly roll your head in circles - 5 times each way', icon: '🧘' },
    { name: 'Shoulder Shrug', desc: 'Lift shoulders up to ears, then release - 10 times', icon: '💪' },
    { name: 'Arm Stretch', desc: 'Reach arms up high and stretch - hold 10 seconds', icon: '🙆' },
    { name: 'Wrist Roll', desc: 'Roll wrists in circles - 10 each direction', icon: '✋' },
    { name: 'Back Stretch', desc: 'Gently arch back and then round it - 5 times', icon: '🤸' },
    { name: 'Leg Stretch', desc: 'Stand up and stretch your legs - 30 seconds', icon: '🦵' },
  ];
  
  const [completedStretches, setCompletedStretches] = useState<number[]>([]);
  
  const toggleStretch = (i: number) => {
    if (completedStretches.includes(i)) {
      setCompletedStretches(cs => cs.filter(c => c !== i));
    } else {
      const updated = [...completedStretches, i];
      setCompletedStretches(updated);
      if (updated.length === stretches.length) onComplete();
    }
  };
  
  return (
    <div className="bg-white rounded-3xl p-6 shadow-xl">
      <h2 className="text-3xl font-black mb-4 text-gray-800">Gentle Stretches</h2>
      <p className="text-gray-600 mb-6">Complete each stretch at your own pace. Check them off as you go! ✨</p>
      
      <div className="space-y-3">
        {stretches.map((s, i) => (
          <button
            key={i}
            onClick={() => toggleStretch(i)}
            className={`w-full p-4 rounded-2xl text-left flex items-center gap-4 transition-all ${
              completedStretches.includes(i)
                ? 'bg-gradient-to-r from-green-400 to-emerald-500 text-white'
                : 'bg-purple-50 hover:bg-purple-100'
            }`}
          >
            <div className="text-4xl">{s.icon}</div>
            <div className="flex-1">
              <div className="font-bold">{s.name}</div>
              <div className="text-sm opacity-90">{s.desc}</div>
            </div>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
              completedStretches.includes(i) ? 'bg-white text-green-600' : 'bg-white'
            }`}>
              {completedStretches.includes(i) ? '✓' : ''}
            </div>
          </button>
        ))}
      </div>
      
      <div className="mt-4 text-center text-sm text-gray-500">
        {completedStretches.length} / {stretches.length} completed
      </div>
    </div>
  );
}

function EyeRest({ onComplete }: { onComplete: () => void }) {
  const [seconds, setSeconds] = useState(20);
  const [done, setDone] = useState(false);
  
  useEffect(() => {
    if (done) return;
    const t = setInterval(() => {
      setSeconds(s => {
        if (s <= 1) {
          setDone(true);
          onComplete();
          return 0;
        }
        return s - 1;
      });
    }, 1000);
    return () => clearInterval(t);
  }, [done, onComplete]);
  
  return (
    <div className="bg-white rounded-3xl p-8 shadow-xl text-center">
      <h2 className="text-3xl font-black mb-4 text-gray-800">👁️ Eye Rest (20-20-20 Rule)</h2>
      <p className="text-gray-600 mb-6">
        Look at something 20 feet (6 meters) away for 20 seconds.
      </p>
      
      <div className="relative w-64 h-64 mx-auto mb-6">
        <div className="absolute inset-0 rounded-full bg-gradient-to-br from-indigo-300 to-purple-400 animate-pulse opacity-50"></div>
        <div className="absolute inset-4 rounded-full bg-gradient-to-br from-indigo-400 to-purple-500 flex items-center justify-center shadow-2xl">
          <div className="text-center text-white">
            <div className="text-6xl font-black">{seconds}</div>
            <div className="text-sm mt-2">seconds</div>
          </div>
        </div>
      </div>
      
      <p className="text-lg text-gray-700">
        {done ? '✨ Perfect! Your eyes thank you!' : '🌿 Look away from the screen now...'}
      </p>
    </div>
  );
}

function AffirmationCards({ onComplete }: { onComplete: () => void }) {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [shown, setShown] = useState(0);
  
  useEffect(() => {
    if (shown >= 5) {
      onComplete();
    }
  }, [shown, onComplete]);
  
  const next = () => {
    setCurrentIdx(i => (i + 1) % affirmations.length);
    setShown(s => s + 1);
  };
  
  return (
    <div className="bg-white rounded-3xl p-8 shadow-xl text-center">
      <h2 className="text-3xl font-black mb-6 text-gray-800">💫 Positive Affirmations</h2>
      
      <div className="min-h-[200px] flex items-center justify-center mb-6">
        <div className="bg-gradient-to-br from-yellow-300 via-orange-300 to-pink-300 rounded-3xl p-8 shadow-xl w-full animate-bounce-in" key={currentIdx}>
          <p className="text-2xl font-bold text-gray-800">
            {affirmations[currentIdx]}
          </p>
        </div>
      </div>
      
      <button
        onClick={next}
        className="px-8 py-3 bg-gradient-to-r from-yellow-400 to-orange-500 text-white font-bold rounded-full shadow-lg hover:scale-105 transition-transform"
      >
        Next Affirmation →
      </button>
      
      <div className="mt-4 text-sm text-gray-500">
        {Math.min(shown, 5)} / 5 completed
      </div>
    </div>
  );
}

function GratitudeReflection({ onComplete }: { onComplete: () => void }) {
  const [items, setItems] = useState(['', '', '']);
  const [submitted, setSubmitted] = useState(false);
  
  const submit = () => {
    setSubmitted(true);
    onComplete();
  };
  
  return (
    <div className="bg-white rounded-3xl p-8 shadow-xl">
      <h2 className="text-3xl font-black mb-4 text-center text-gray-800">🙏 Gratitude Reflection</h2>
      <p className="text-center text-gray-600 mb-6">
        Write down 3 things you're grateful for today. They can be big or small!
      </p>
      
      {!submitted ? (
        <div className="space-y-4">
          {items.map((item, i) => (
            <div key={i} className="flex items-center gap-3">
              <div className="text-3xl">
                {['🌟', '🌈', '💖'][i]}
              </div>
              <input
                type="text"
                value={item}
                onChange={e => {
                  const newItems = [...items];
                  newItems[i] = e.target.value;
                  setItems(newItems);
                }}
                placeholder={`Thing ${i + 1}...`}
                className="flex-1 p-4 rounded-2xl border-2 border-pink-200 focus:border-pink-500 outline-none"
              />
            </div>
          ))}
          
          <button
            onClick={submit}
            disabled={items.some(i => !i.trim())}
            className="w-full py-4 bg-gradient-to-r from-pink-500 to-rose-500 text-white font-bold rounded-2xl shadow-xl hover:scale-105 transition-transform disabled:opacity-50"
          >
            ✨ Complete Reflection
          </button>
        </div>
      ) : (
        <div className="text-center animate-bounce-in">
          <div className="text-7xl mb-4">🌸</div>
          <h3 className="text-2xl font-black bg-gradient-to-r from-pink-500 to-rose-500 bg-clip-text text-transparent mb-3">
            Gratitude Recorded!
          </h3>
          <p className="text-gray-600">Thank you for taking a moment to appreciate the good things in your life. 🙏</p>
          <div className="mt-6 space-y-2">
            {items.map((item, i) => (
              <div key={i} className="p-3 bg-pink-50 rounded-xl text-left">
                <span className="font-bold text-pink-600">{['🌟', '🌈', '💖'][i]}</span> {item}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
