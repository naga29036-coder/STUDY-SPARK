import { useState } from 'react';
import Layout, { Confetti } from '../components/Layout';
import { dailyChallenges } from '../data/quizData';
import { getDailyChallengeIndex, isDailyChallengeCompletedToday, recordDailyChallenge } from '../utils/storage';

export default function DailyChallenge() {
  const challengeIndex = getDailyChallengeIndex();
  const challenge = dailyChallenges[challengeIndex];
  const alreadyClaimed = isDailyChallengeCompletedToday();
  
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [result, setResult] = useState<{ xpEarned: number; alreadyClaimed: boolean } | null>(null);
  const [confettiTrigger, setConfettiTrigger] = useState(0);
  
  const handleAnswer = (idx: number) => {
    if (selectedAnswer !== null) return;
    setSelectedAnswer(idx);
    setShowExplanation(true);
    
    const isCorrect = idx === challenge.correctAnswer;
    const result = recordDailyChallenge(challenge.id, isCorrect, challenge.rewardPoints);
    setResult(result);
    
    if (isCorrect) {
      setConfettiTrigger(t => t + 1);
    }
  };
  
  const today = new Date();
  const dateString = today.toLocaleDateString('en-US', { 
    weekday: 'long', 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  });
  
  return (
    <Layout title="⭐ Daily Challenge">
      <Confetti trigger={confettiTrigger} />
      
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="rounded-3xl bg-gradient-to-br from-yellow-400 via-orange-500 to-red-500 p-8 text-white shadow-2xl mb-6">
          <div className="text-center">
            <div className="text-7xl mb-3 animate-float">⭐</div>
            <h1 className="text-4xl font-black mb-2">Daily Challenge</h1>
            <p className="text-white/90">A new challenge every day!</p>
            <div className="mt-4 inline-block bg-white/20 backdrop-blur rounded-full px-4 py-2">
              <div className="text-sm font-semibold">{dateString}</div>
            </div>
          </div>
        </div>
        
        {alreadyClaimed && !result && (
          <div className="bg-gradient-to-r from-green-400 to-emerald-500 text-white rounded-2xl p-4 text-center mb-6 shadow-lg animate-bounce-in">
            <div className="font-bold text-lg">🎉 You've already completed today's challenge!</div>
            <div className="text-sm opacity-90 mt-1">Come back tomorrow for a new one!</div>
          </div>
        )}
        
        {/* Challenge card */}
        <div className="bg-white rounded-3xl p-6 md:p-8 shadow-xl mb-6">
          <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
            <div className="flex items-center gap-3">
              <div className="text-4xl">{challenge.icon}</div>
              <div>
                <div className="text-xs text-gray-500">Category</div>
                <div className="font-bold">{challenge.category}</div>
              </div>
            </div>
            <div className="flex gap-2">
              <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                challenge.difficulty === 'easy' ? 'bg-green-100 text-green-700' :
                challenge.difficulty === 'medium' ? 'bg-yellow-100 text-yellow-700' :
                'bg-red-100 text-red-700'
              }`}>
                {challenge.difficulty}
              </span>
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-yellow-100 text-yellow-700">
                +{challenge.rewardPoints} XP
              </span>
            </div>
          </div>
          
          <h2 className="text-xl md:text-2xl font-bold text-gray-800 mb-6">
            {challenge.question}
          </h2>
          
          <div className="space-y-3 mb-6">
            {challenge.options.map((opt, idx) => {
              const isSelected = selectedAnswer === idx;
              const isCorrect = idx === challenge.correctAnswer;
              const showResult = selectedAnswer !== null;
              
              let btnClass = 'border-2 border-gray-200 bg-gray-50 hover:border-yellow-400 hover:bg-yellow-50';
              if (showResult) {
                if (isCorrect) btnClass = 'border-2 border-green-500 bg-green-50';
                else if (isSelected) btnClass = 'border-2 border-red-500 bg-red-50';
                else btnClass = 'border-2 border-gray-200 bg-gray-50 opacity-60';
              }
              
              return (
                <button
                  key={idx}
                  onClick={() => handleAnswer(idx)}
                  disabled={selectedAnswer !== null || alreadyClaimed}
                  className={`w-full p-4 rounded-2xl text-left font-semibold transition-all ${btnClass} disabled:cursor-not-allowed`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                      showResult && isCorrect ? 'bg-green-500 text-white' :
                      showResult && isSelected ? 'bg-red-500 text-white' :
                      'bg-yellow-100 text-yellow-700'
                    }`}>
                      {String.fromCharCode(65 + idx)}
                    </div>
                    <span className="flex-1">{opt}</span>
                    {showResult && isCorrect && <span className="text-2xl">✓</span>}
                    {showResult && isSelected && !isCorrect && <span className="text-2xl">✗</span>}
                  </div>
                </button>
              );
            })}
          </div>
          
          {showExplanation && (
            <div className="p-4 rounded-2xl bg-blue-50 border border-blue-200 animate-slide-up">
              <div className="font-bold text-blue-900 mb-1">💡 Explanation</div>
              <p className="text-sm text-blue-800">{challenge.explanation}</p>
            </div>
          )}
          
          {result && result.xpEarned > 0 && (
            <div className="mt-4 p-4 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-2xl text-white text-center animate-bounce-in">
              <div className="font-bold text-lg">🎉 +{result.xpEarned} Brain XP earned!</div>
            </div>
          )}
        </div>
        
        {/* Tips */}
        <div className="bg-white rounded-2xl p-5 shadow-lg text-sm text-gray-600">
          <div className="font-bold text-gray-800 mb-2">💡 Tips</div>
          <ul className="list-disc list-inside space-y-1">
            <li>One challenge per day - take your time!</li>
            <li>Points are awarded only for correct answers</li>
            <li>Come back daily to keep your streak going!</li>
            <li>Every challenge helps sharpen your brain 🧠</li>
          </ul>
        </div>
      </div>
    </Layout>
  );
}
