import { useState } from 'react';
import Layout, { Confetti } from '../components/Layout';
import { puzzles } from '../data/quizData';
import { recordGameResult } from '../utils/storage';

export default function PuzzlesPage() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showHint, setShowHint] = useState(false);
  const [showExplanation, setShowExplanation] = useState(false);
  const [score, setScore] = useState(0);
  const [completed, setCompleted] = useState(0);
  const [confettiTrigger, setConfettiTrigger] = useState(0);
  const [filterType, setFilterType] = useState<string>('all');
  
  const filteredPuzzles = filterType === 'all' 
    ? puzzles 
    : puzzles.filter(p => p.type === filterType);
  
  const puzzle = filteredPuzzles[currentIndex % filteredPuzzles.length];
  
  if (!puzzle) {
    return (
      <Layout title="🧩 Puzzles">
        <div className="text-center py-20">
          <div className="text-6xl mb-4">😕</div>
          <h2 className="text-2xl font-bold">No puzzles available</h2>
        </div>
      </Layout>
    );
  }
  
  const handleAnswer = (idx: number) => {
    if (selectedAnswer !== null) return;
    setSelectedAnswer(idx);
    setShowExplanation(true);
    
    if (idx === puzzle.correctAnswer) {
      setScore(s => s + puzzle.rewardPoints);
      setCompleted(c => c + 1);
      setConfettiTrigger(t => t + 1);
      recordGameResult('puzzle', puzzle.difficulty, puzzle.rewardPoints, 0, 0);
    }
  };
  
  const nextPuzzle = () => {
    setCurrentIndex(i => (i + 1) % filteredPuzzles.length);
    setSelectedAnswer(null);
    setShowHint(false);
    setShowExplanation(false);
  };
  
  const typeColors: Record<string, string> = {
    sequence: 'from-purple-500 to-pink-500',
    oddout: 'from-orange-500 to-red-500',
    pattern: 'from-cyan-500 to-blue-500',
    riddle: 'from-green-500 to-teal-500',
    math: 'from-yellow-400 to-orange-500',
  };
  
  const typeIcons: Record<string, string> = {
    sequence: '🔢',
    oddout: '🎯',
    pattern: '🎨',
    riddle: '🤔',
    math: '➕',
  };
  
  return (
    <Layout title="🧩 Logic Puzzles">
      <Confetti trigger={confettiTrigger} />
      
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <div className="rounded-3xl bg-gradient-to-br from-emerald-500 via-teal-500 to-cyan-500 p-8 text-white shadow-2xl mb-6">
          <h1 className="text-4xl font-black text-center mb-2">Logic & Number Puzzles</h1>
          <p className="text-center text-white/90">Challenge your brain with these puzzles! 🧠</p>
          
          <div className="flex justify-center gap-3 mt-4">
            <div className="bg-white/20 backdrop-blur rounded-full px-4 py-2">
              <span className="font-bold">Score: {score}</span>
            </div>
            <div className="bg-white/20 backdrop-blur rounded-full px-4 py-2">
              <span className="font-bold">Solved: {completed}</span>
            </div>
          </div>
        </div>
        
        {/* Filter */}
        <div className="flex flex-wrap gap-2 mb-6">
          {['all', 'sequence', 'oddout', 'pattern', 'riddle', 'math'].map(type => (
            <button
              key={type}
              onClick={() => { setFilterType(type); setCurrentIndex(0); setSelectedAnswer(null); setShowHint(false); setShowExplanation(false); }}
              className={`px-4 py-2 rounded-full font-semibold text-sm transition-all ${
                filterType === type
                  ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg'
                  : 'bg-white text-gray-700 shadow hover:scale-105'
              }`}
            >
              {type === 'all' ? '🌟 All' : `${typeIcons[type] || ''} ${type.charAt(0).toUpperCase() + type.slice(1)}`}
            </button>
          ))}
        </div>
        
        {/* Puzzle card */}
        <div className={`rounded-3xl bg-gradient-to-br ${typeColors[puzzle.type]} p-1 shadow-xl mb-6 animate-slide-up`}>
          <div className="bg-white rounded-3xl p-6 md:p-8">
            <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <span className="text-4xl">{typeIcons[puzzle.type]}</span>
                <div>
                  <div className="font-bold text-lg">{puzzle.title}</div>
                  <div className="text-xs text-gray-500 capitalize">{puzzle.type} Puzzle</div>
                </div>
              </div>
              <div className="flex gap-2">
                <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                  puzzle.difficulty === 'easy' ? 'bg-green-100 text-green-700' :
                  puzzle.difficulty === 'medium' ? 'bg-yellow-100 text-yellow-700' :
                  'bg-red-100 text-red-700'
                }`}>
                  {puzzle.difficulty}
                </span>
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-purple-100 text-purple-700">
                  +{puzzle.rewardPoints} XP
                </span>
              </div>
            </div>
            
            <h2 className="text-2xl font-bold text-gray-800 mb-6">
              {puzzle.question}
            </h2>
            
            {/* Hint */}
            {showHint && (
              <div className="mb-4 p-3 bg-yellow-50 rounded-2xl border border-yellow-200 animate-fade-in">
                <div className="font-semibold text-yellow-900 text-sm">💡 Hint: {puzzle.hint}</div>
              </div>
            )}
            
            <div className="grid grid-cols-2 gap-3 mb-6">
              {puzzle.options.map((opt, idx) => {
                const isSelected = selectedAnswer === idx;
                const isCorrect = idx === puzzle.correctAnswer;
                const showResult = selectedAnswer !== null;
                
                let btnClass = 'border-2 border-gray-200 bg-gray-50 hover:border-purple-400 hover:bg-purple-50';
                if (showResult) {
                  if (isCorrect) btnClass = 'border-2 border-green-500 bg-green-50';
                  else if (isSelected) btnClass = 'border-2 border-red-500 bg-red-50';
                  else btnClass = 'border-2 border-gray-200 bg-gray-50 opacity-60';
                }
                
                return (
                  <button
                    key={idx}
                    onClick={() => handleAnswer(idx)}
                    disabled={selectedAnswer !== null}
                    className={`p-4 rounded-2xl font-semibold transition-all ${btnClass}`}
                  >
                    {opt}
                  </button>
                );
              })}
            </div>
            
            {/* Explanation */}
            {showExplanation && (
              <div className="p-4 rounded-2xl bg-blue-50 border border-blue-200 animate-slide-up mb-4">
                <div className="font-bold text-blue-900 mb-1">💡 Explanation</div>
                <p className="text-sm text-blue-800">{puzzle.explanation}</p>
              </div>
            )}
            
            {/* Actions */}
            <div className="flex flex-wrap gap-3">
              {!showHint && selectedAnswer === null && (
                <button
                  onClick={() => setShowHint(true)}
                  className="flex-1 py-3 bg-yellow-100 text-yellow-800 font-bold rounded-2xl hover:bg-yellow-200 transition-colors"
                >
                  💡 Show Hint
                </button>
              )}
              {selectedAnswer !== null && (
                <button
                  onClick={nextPuzzle}
                  className="flex-1 py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold rounded-2xl hover:scale-105 transition-transform"
                >
                  Next Puzzle →
                </button>
              )}
            </div>
          </div>
        </div>
        
        {/* Instructions */}
        <div className="bg-white rounded-2xl p-5 shadow-lg text-sm text-gray-600">
          <div className="font-bold text-gray-800 mb-2">📖 How to play</div>
          <ul className="list-disc list-inside space-y-1">
            <li>Read each puzzle carefully</li>
            <li>Use the hint if you're stuck</li>
            <li>Learn from explanations for wrong answers</li>
            <li>Earn points and improve your logical thinking!</li>
          </ul>
        </div>
      </div>
    </Layout>
  );
}
