import { useState, useEffect } from 'react';
import Layout, { Confetti } from '../components/Layout';
import { recordGameResult } from '../utils/storage';

type Difficulty = 'easy' | 'medium' | 'hard';

const difficultyConfig = {
  easy: { pairs: 6, cols: 4, label: 'Easy (3x4)' },
  medium: { pairs: 8, cols: 4, label: 'Medium (4x4)' },
  hard: { pairs: 12, cols: 6, label: 'Hard (4x6)' },
};

const cardEmojis = ['🎮', '🎨', '🎭', '🎯', '🎲', '🎸', '🎺', '🎻', '🎬', '🎪', '🎡', '🎢', '🚀', '🛸', '🌟', '💎'];

interface Card {
  id: number;
  emoji: string;
  flipped: boolean;
  matched: boolean;
}

export default function MemoryGame() {
  const [difficulty, setDifficulty] = useState<Difficulty>('easy');
  const [cards, setCards] = useState<Card[]>([]);
  const [flippedIds, setFlippedIds] = useState<number[]>([]);
  const [moves, setMoves] = useState(0);
  const [time, setTime] = useState(0);
  const [started, setStarted] = useState(false);
  const [finished, setFinished] = useState(false);
  const [bestScore, setBestScore] = useState<number | null>(null);
  const [confettiTrigger, setConfettiTrigger] = useState(0);
  
  const config = difficultyConfig[difficulty];
  
  const initGame = (diff: Difficulty) => {
    const cfg = difficultyConfig[diff];
    const selectedEmojis = cardEmojis.slice(0, cfg.pairs);
    const deck = [...selectedEmojis, ...selectedEmojis]
      .sort(() => Math.random() - 0.5)
      .map((emoji, id) => ({ id, emoji, flipped: false, matched: false }));
    setCards(deck);
    setFlippedIds([]);
    setMoves(0);
    setTime(0);
    setStarted(false);
    setFinished(false);
    
    // Load best score
    const key = `memory_best_${diff}`;
    const saved = localStorage.getItem(key);
    setBestScore(saved ? parseInt(saved) : null);
  };
  
  useEffect(() => {
    initGame(difficulty);
  }, [difficulty]);
  
  useEffect(() => {
    if (!started || finished) return;
    const t = setInterval(() => setTime(s => s + 1), 1000);
    return () => clearInterval(t);
  }, [started, finished]);
  
  useEffect(() => {
    if (flippedIds.length === 2) {
      const [a, b] = flippedIds;
      const cardA = cards.find(c => c.id === a);
      const cardB = cards.find(c => c.id === b);
      
      if (cardA && cardB && cardA.emoji === cardB.emoji) {
        setTimeout(() => {
          setCards(cs => cs.map(c => 
            c.id === a || c.id === b ? { ...c, matched: true } : c
          ));
          setFlippedIds([]);
        }, 500);
      } else {
        setTimeout(() => {
          setCards(cs => cs.map(c => 
            c.id === a || c.id === b ? { ...c, flipped: false } : c
          ));
          setFlippedIds([]);
        }, 1000);
      }
    }
  }, [flippedIds]);
  
  // Check for completion
  useEffect(() => {
    if (cards.length > 0 && cards.every(c => c.matched) && !finished) {
      setFinished(true);
      setConfettiTrigger(t => t + 1);
      
      // Calculate score
      const score = Math.max(10, 1000 - moves * 10 - time * 2);
      
      // Save best
      const key = `memory_best_${difficulty}`;
      const saved = localStorage.getItem(key);
      const current = saved ? parseInt(saved) : 0;
      if (score > current) {
        localStorage.setItem(key, score.toString());
        setBestScore(score);
      }
      
      // Record result
      recordGameResult('memory', difficulty, score, time, moves);
    }
  }, [cards, finished, moves, time, difficulty]);
  
  const flipCard = (id: number) => {
    if (!started) setStarted(true);
    if (flippedIds.length >= 2) return;
    if (flippedIds.includes(id)) return;
    
    const card = cards.find(c => c.id === id);
    if (!card || card.matched || card.flipped) return;
    
    setCards(cs => cs.map(c => c.id === id ? { ...c, flipped: true } : c));
    setFlippedIds(prev => [...prev, id]);
    if (flippedIds.length === 1) setMoves(m => m + 1);
  };
  
  const formatTime = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m}:${sec.toString().padStart(2, '0')}`;
  };
  
  return (
    <Layout title="🧠 Memory Game">
      <Confetti trigger={confettiTrigger} />
      
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="rounded-3xl bg-gradient-to-br from-cyan-500 via-blue-500 to-purple-600 p-8 text-white shadow-2xl mb-6">
          <h1 className="text-4xl font-black text-center mb-2">Memory Game</h1>
          <p className="text-center text-white/90">Match all pairs to win! 🎯</p>
        </div>
        
        {/* Difficulty selector */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          {(Object.keys(difficultyConfig) as Difficulty[]).map(d => (
            <button
              key={d}
              onClick={() => setDifficulty(d)}
              disabled={started && !finished}
              className={`py-3 rounded-2xl font-bold transition-all ${
                difficulty === d
                  ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg scale-105'
                  : 'bg-white text-gray-700 shadow hover:scale-105'
              } disabled:opacity-50`}
            >
              {difficultyConfig[d].label}
            </button>
          ))}
        </div>
        
        {/* Stats */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          <div className="bg-white rounded-2xl p-4 shadow-lg text-center">
            <div className="text-xs text-gray-500">Moves</div>
            <div className="text-2xl font-black text-purple-600">{moves}</div>
          </div>
          <div className="bg-white rounded-2xl p-4 shadow-lg text-center">
            <div className="text-xs text-gray-500">Time</div>
            <div className="text-2xl font-black text-cyan-600">{formatTime(time)}</div>
          </div>
          <div className="bg-white rounded-2xl p-4 shadow-lg text-center">
            <div className="text-xs text-gray-500">Best</div>
            <div className="text-2xl font-black text-yellow-600">{bestScore ?? '—'}</div>
          </div>
        </div>
        
        {/* Game grid */}
        <div 
          className="grid gap-2 md:gap-3 mb-6"
          style={{ gridTemplateColumns: `repeat(${config.cols}, minmax(0, 1fr))` }}
        >
          {cards.map(card => (
            <button
              key={card.id}
              onClick={() => flipCard(card.id)}
              className={`aspect-square rounded-2xl font-bold text-2xl md:text-4xl transition-all duration-300 ${
                card.flipped || card.matched
                  ? card.matched
                    ? 'bg-gradient-to-br from-green-400 to-emerald-500 text-white scale-95 shadow-inner'
                    : 'bg-gradient-to-br from-yellow-300 to-orange-400 text-white shadow-xl scale-105'
                  : 'bg-gradient-to-br from-purple-500 to-pink-500 text-white shadow-lg hover:scale-105'
              }`}
              disabled={card.matched}
            >
              {card.flipped || card.matched ? card.emoji : '?'}
            </button>
          ))}
        </div>
        
        {/* Restart */}
        <div className="text-center">
          <button
            onClick={() => initGame(difficulty)}
            className="px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold rounded-full shadow-lg hover:scale-105 transition-transform"
          >
            🔄 Restart Game
          </button>
        </div>
        
        {/* Victory Modal */}
        {finished && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
            <div className="bg-white rounded-3xl p-8 max-w-md w-full shadow-2xl animate-bounce-in text-center">
              <div className="text-7xl mb-4">🎉</div>
              <h2 className="text-3xl font-black mb-4 bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                You Did It!
              </h2>
              <div className="grid grid-cols-2 gap-3 mb-6">
                <div className="bg-purple-50 rounded-2xl p-4">
                  <div className="text-xs text-gray-500">Moves</div>
                  <div className="text-2xl font-black text-purple-600">{moves}</div>
                </div>
                <div className="bg-cyan-50 rounded-2xl p-4">
                  <div className="text-xs text-gray-500">Time</div>
                  <div className="text-2xl font-black text-cyan-600">{formatTime(time)}</div>
                </div>
              </div>
              <div className="bg-gradient-to-r from-purple-500 to-pink-500 rounded-2xl p-4 text-white mb-6">
                <div className="text-sm">Score</div>
                <div className="text-4xl font-black">{Math.max(10, 1000 - moves * 10 - time * 2)}</div>
              </div>
              <button
                onClick={() => initGame(difficulty)}
                className="w-full py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold rounded-2xl shadow-lg hover:scale-105 transition-transform"
              >
                🔄 Play Again
              </button>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
}
