// Quiz questions organized by category and difficulty
export interface Question {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number; // index of correct option
  explanation: string;
  difficulty: 'easy' | 'medium' | 'hard';
}

export interface Quiz {
  id: string;
  title: string;
  category: string;
  icon: string;
  color: string;
  description: string;
  questions: Question[];
}

export const quizzes: Quiz[] = [
  {
    id: 'general',
    title: 'General Knowledge',
    category: 'General',
    icon: '🌍',
    color: 'from-purple-500 to-pink-500',
    description: 'Test your knowledge of the world!',
    questions: [
      { id: 'g1', question: 'What is the capital of Australia?', options: ['Sydney', 'Melbourne', 'Canberra', 'Perth'], correctAnswer: 2, explanation: 'Canberra is the capital of Australia, not Sydney or Melbourne.', difficulty: 'easy' },
      { id: 'g2', question: 'How many continents are there?', options: ['5', '6', '7', '8'], correctAnswer: 2, explanation: 'There are 7 continents: Africa, Antarctica, Asia, Australia, Europe, North America, and South America.', difficulty: 'easy' },
      { id: 'g3', question: 'Which planet is known as the Red Planet?', options: ['Venus', 'Mars', 'Jupiter', 'Saturn'], correctAnswer: 1, explanation: 'Mars appears red due to iron oxide (rust) on its surface.', difficulty: 'easy' },
      { id: 'g4', question: 'Who painted the Mona Lisa?', options: ['Van Gogh', 'Picasso', 'Leonardo da Vinci', 'Michelangelo'], correctAnswer: 2, explanation: 'Leonardo da Vinci painted the Mona Lisa between 1503 and 1519.', difficulty: 'easy' },
      { id: 'g5', question: 'What is the largest ocean on Earth?', options: ['Atlantic', 'Indian', 'Arctic', 'Pacific'], correctAnswer: 3, explanation: 'The Pacific Ocean is the largest, covering about 63 million square miles.', difficulty: 'easy' },
      { id: 'g6', question: 'Which country has the most natural lakes?', options: ['USA', 'Russia', 'Canada', 'Finland'], correctAnswer: 2, explanation: 'Canada has over 2 million lakes, more than any other country.', difficulty: 'medium' },
      { id: 'g7', question: 'What year did the Titanic sink?', options: ['1910', '1912', '1915', '1920'], correctAnswer: 1, explanation: 'The Titanic sank on April 15, 1912, after hitting an iceberg.', difficulty: 'medium' },
      { id: 'g8', question: 'What is the smallest country in the world?', options: ['Monaco', 'Vatican City', 'San Marino', 'Liechtenstein'], correctAnswer: 1, explanation: 'Vatican City is the smallest country, covering just 44 hectares.', difficulty: 'medium' },
      { id: 'g9', question: 'Which language has the most native speakers?', options: ['English', 'Spanish', 'Mandarin Chinese', 'Hindi'], correctAnswer: 2, explanation: 'Mandarin Chinese has about 920 million native speakers.', difficulty: 'hard' },
      { id: 'g10', question: 'What is the longest river in the world?', options: ['Amazon', 'Nile', 'Yangtze', 'Mississippi'], correctAnswer: 1, explanation: 'The Nile River is traditionally considered the longest at about 6,650 km.', difficulty: 'hard' },
    ],
  },
  {
    id: 'science',
    title: 'Science',
    category: 'Science',
    icon: '🔬',
    color: 'from-cyan-500 to-blue-500',
    description: 'Explore the wonders of science!',
    questions: [
      { id: 's1', question: 'What is the chemical symbol for gold?', options: ['Go', 'Gd', 'Au', 'Ag'], correctAnswer: 2, explanation: 'Au comes from the Latin word "aurum" meaning gold.', difficulty: 'easy' },
      { id: 's2', question: 'What is the speed of light?', options: ['300,000 km/s', '150,000 km/s', '500,000 km/s', '1,000,000 km/s'], correctAnswer: 0, explanation: 'Light travels at approximately 299,792 km/s in a vacuum.', difficulty: 'easy' },
      { id: 's3', question: 'What is the powerhouse of the cell?', options: ['Nucleus', 'Ribosome', 'Mitochondria', 'Golgi body'], correctAnswer: 2, explanation: 'Mitochondria produce ATP, the cell\'s energy currency.', difficulty: 'easy' },
      { id: 's4', question: 'Which gas do plants absorb from the atmosphere?', options: ['Oxygen', 'Carbon dioxide', 'Nitrogen', 'Hydrogen'], correctAnswer: 1, explanation: 'Plants absorb CO2 for photosynthesis and release oxygen.', difficulty: 'easy' },
      { id: 's5', question: 'What is the hardest natural substance?', options: ['Gold', 'Iron', 'Diamond', 'Platinum'], correctAnswer: 2, explanation: 'Diamond scores 10 on the Mohs hardness scale.', difficulty: 'easy' },
      { id: 's6', question: 'What is the atomic number of carbon?', options: ['4', '6', '8', '12'], correctAnswer: 1, explanation: 'Carbon has 6 protons, so its atomic number is 6.', difficulty: 'medium' },
      { id: 's7', question: 'Which force keeps planets in orbit?', options: ['Magnetic', 'Nuclear', 'Gravity', 'Friction'], correctAnswer: 2, explanation: 'Gravity from the Sun keeps planets in orbit.', difficulty: 'medium' },
      { id: 's8', question: 'What is the pH of pure water?', options: ['5', '6', '7', '8'], correctAnswer: 2, explanation: 'Pure water has a neutral pH of 7.', difficulty: 'medium' },
      { id: 's9', question: 'What particle has a negative charge?', options: ['Proton', 'Neutron', 'Electron', 'Photon'], correctAnswer: 2, explanation: 'Electrons carry a negative electric charge.', difficulty: 'medium' },
      { id: 's10', question: 'What is the most abundant gas in Earth\'s atmosphere?', options: ['Oxygen', 'Carbon dioxide', 'Nitrogen', 'Argon'], correctAnswer: 2, explanation: 'Nitrogen makes up about 78% of Earth\'s atmosphere.', difficulty: 'hard' },
    ],
  },
  {
    id: 'math',
    title: 'Mathematics',
    category: 'Math',
    icon: '🔢',
    color: 'from-yellow-500 to-orange-500',
    description: 'Challenge your math skills!',
    questions: [
      { id: 'm1', question: 'What is 15% of 200?', options: ['20', '25', '30', '35'], correctAnswer: 2, explanation: '15% × 200 = 0.15 × 200 = 30.', difficulty: 'easy' },
      { id: 'm2', question: 'What is the square root of 144?', options: ['10', '11', '12', '13'], correctAnswer: 2, explanation: '12 × 12 = 144, so √144 = 12.', difficulty: 'easy' },
      { id: 'm3', question: 'What is 7 × 8?', options: ['54', '56', '58', '62'], correctAnswer: 1, explanation: '7 × 8 = 56.', difficulty: 'easy' },
      { id: 'm4', question: 'How many sides does a hexagon have?', options: ['5', '6', '7', '8'], correctAnswer: 1, explanation: 'A hexagon has 6 sides.', difficulty: 'easy' },
      { id: 'm5', question: 'What is 2³?', options: ['6', '8', '9', '12'], correctAnswer: 1, explanation: '2³ = 2 × 2 × 2 = 8.', difficulty: 'easy' },
      { id: 'm6', question: 'What is the value of π (pi) to 2 decimal places?', options: ['3.12', '3.14', '3.16', '3.18'], correctAnswer: 1, explanation: 'π ≈ 3.14159..., so to 2 decimals it\'s 3.14.', difficulty: 'medium' },
      { id: 'm7', question: 'What is the sum of angles in a triangle?', options: ['90°', '180°', '270°', '360°'], correctAnswer: 1, explanation: 'The angles in any triangle always sum to 180°.', difficulty: 'medium' },
      { id: 'm8', question: 'What is 12²?', options: ['124', '132', '144', '156'], correctAnswer: 2, explanation: '12 × 12 = 144.', difficulty: 'medium' },
      { id: 'm9', question: 'What is the next prime number after 7?', options: ['8', '9', '10', '11'], correctAnswer: 3, explanation: '8, 9, and 10 are not prime. 11 is the next prime after 7.', difficulty: 'medium' },
      { id: 'm10', question: 'What is log₁₀(1000)?', options: ['2', '3', '4', '10'], correctAnswer: 1, explanation: '10³ = 1000, so log₁₀(1000) = 3.', difficulty: 'hard' },
    ],
  },
  {
    id: 'cs',
    title: 'Computer Science',
    category: 'CS',
    icon: '💻',
    color: 'from-indigo-500 to-purple-500',
    description: 'Test your computer science knowledge!',
    questions: [
      { id: 'c1', question: 'What does CPU stand for?', options: ['Central Process Unit', 'Central Processing Unit', 'Computer Personal Unit', 'Central Processor Utility'], correctAnswer: 1, explanation: 'CPU = Central Processing Unit, the main processor of a computer.', difficulty: 'easy' },
      { id: 'c2', question: 'What does HTML stand for?', options: ['Hyper Text Markup Language', 'High Tech Modern Language', 'Home Tool Markup Language', 'Hyperlink Text Mode Language'], correctAnswer: 0, explanation: 'HTML = HyperText Markup Language, used for web pages.', difficulty: 'easy' },
      { id: 'c3', question: 'Which is NOT a programming language?', options: ['Python', 'Java', 'HTML', 'C++'], correctAnswer: 2, explanation: 'HTML is a markup language, not a programming language.', difficulty: 'easy' },
      { id: 'c4', question: 'What does RAM stand for?', options: ['Read Access Memory', 'Random Access Memory', 'Rapid Access Memory', 'Read Anywhere Memory'], correctAnswer: 1, explanation: 'RAM = Random Access Memory, volatile working memory.', difficulty: 'easy' },
      { id: 'c5', question: 'Binary number 1010 equals what in decimal?', options: ['8', '10', '12', '14'], correctAnswer: 1, explanation: '1010 in binary = 8 + 2 = 10 in decimal.', difficulty: 'easy' },
      { id: 'c6', question: 'Which company created JavaScript?', options: ['Microsoft', 'Google', 'Netscape', 'Apple'], correctAnswer: 2, explanation: 'JavaScript was created by Brendan Eich at Netscape in 1995.', difficulty: 'medium' },
      { id: 'c7', question: 'What is the time complexity of binary search?', options: ['O(n)', 'O(log n)', 'O(n²)', 'O(1)'], correctAnswer: 1, explanation: 'Binary search has O(log n) complexity.', difficulty: 'medium' },
      { id: 'c8', question: 'Which data structure uses FIFO?', options: ['Stack', 'Queue', 'Tree', 'Graph'], correctAnswer: 1, explanation: 'Queue uses First-In-First-Out (FIFO) order.', difficulty: 'medium' },
      { id: 'c9', question: 'What does SQL stand for?', options: ['Structured Query Language', 'Simple Query Language', 'Standard Query Logic', 'Sequential Query Language'], correctAnswer: 0, explanation: 'SQL = Structured Query Language for database queries.', difficulty: 'medium' },
      { id: 'c10', question: 'Which sorting algorithm has the best average case?', options: ['Bubble Sort', 'Selection Sort', 'Quick Sort', 'Insertion Sort'], correctAnswer: 2, explanation: 'Quick Sort has O(n log n) average case, better than O(n²) of others.', difficulty: 'hard' },
    ],
  },
  {
    id: 'python',
    title: 'Python Programming',
    category: 'Python',
    icon: '🐍',
    color: 'from-green-500 to-teal-500',
    description: 'Master your Python skills!',
    questions: [
      { id: 'p1', question: 'Which keyword defines a function in Python?', options: ['function', 'def', 'func', 'define'], correctAnswer: 1, explanation: 'In Python, use "def" to define a function.', difficulty: 'easy' },
      { id: 'p2', question: 'What is the output of print(2 ** 3)?', options: ['6', '8', '9', '5'], correctAnswer: 1, explanation: '** is the exponentiation operator: 2³ = 8.', difficulty: 'easy' },
      { id: 'p3', question: 'Which of these is a list in Python?', options: ['(1,2,3)', '[1,2,3]', '{1,2,3}', '<1,2,3>'], correctAnswer: 1, explanation: 'Lists use square brackets [].', difficulty: 'easy' },
      { id: 'p4', question: 'How do you create a comment in Python?', options: ['// comment', '# comment', '/* comment */', '-- comment'], correctAnswer: 1, explanation: 'Python uses # for single-line comments.', difficulty: 'easy' },
      { id: 'p5', question: 'What does len("Hello") return?', options: ['4', '5', '6', 'Error'], correctAnswer: 1, explanation: 'len() returns the number of characters: "Hello" has 5.', difficulty: 'easy' },
      { id: 'p6', question: 'What is the output of [1,2,3][::-1]?', options: ['[1,2,3]', '[3,2,1]', 'Error', '[1,3,2]'], correctAnswer: 1, explanation: '[::-1] reverses the list.', difficulty: 'medium' },
      { id: 'p7', question: 'Which is immutable in Python?', options: ['List', 'Dictionary', 'Tuple', 'Set'], correctAnswer: 2, explanation: 'Tuples are immutable; lists, dicts, and sets are mutable.', difficulty: 'medium' },
      { id: 'p8', question: 'What does "3" + "4" evaluate to in Python?', options: ['7', '"34"', 'Error', '34'], correctAnswer: 1, explanation: 'String concatenation: "3" + "4" = "34".', difficulty: 'medium' },
      { id: 'p9', question: 'What does the "pass" keyword do?', options: ['Exits program', 'Does nothing', 'Passes variable', 'Skips loop'], correctAnswer: 1, explanation: '"pass" is a null operation; it does nothing.', difficulty: 'medium' },
      { id: 'p10', question: 'What is a Python decorator?', options: ['A comment', 'A function wrapper', 'A class', 'A variable'], correctAnswer: 1, explanation: 'Decorators wrap functions to extend behavior.', difficulty: 'hard' },
    ],
  },
  {
    id: 'logic',
    title: 'Logical Reasoning',
    category: 'Logic',
    icon: '🧩',
    color: 'from-pink-500 to-rose-500',
    description: 'Sharpen your logical thinking!',
    questions: [
      { id: 'l1', question: 'If all roses are flowers and some flowers fade quickly, what is true?', options: ['All roses fade quickly', 'Some roses fade quickly', 'No roses fade quickly', 'Cannot determine'], correctAnswer: 3, explanation: 'We cannot determine if roses are among those that fade quickly.', difficulty: 'medium' },
      { id: 'l2', question: 'What comes next: 2, 4, 8, 16, __?', options: ['24', '30', '32', '36'], correctAnswer: 2, explanation: 'Each number doubles: 16 × 2 = 32.', difficulty: 'easy' },
      { id: 'l3', question: 'Find the odd one out: 3, 5, 7, 9, 11', options: ['3', '5', '9', '11'], correctAnswer: 2, explanation: '9 is the only composite number; others are prime.', difficulty: 'medium' },
      { id: 'l4', question: 'If A > B and B > C, then:', options: ['A < C', 'A = C', 'A > C', 'Cannot determine'], correctAnswer: 2, explanation: 'By transitivity, A > C.', difficulty: 'easy' },
      { id: 'l5', question: 'Complete: 1, 1, 2, 3, 5, 8, __', options: ['10', '11', '12', '13'], correctAnswer: 3, explanation: 'Fibonacci sequence: 5 + 8 = 13.', difficulty: 'medium' },
      { id: 'l6', question: 'If some programmers are musicians and all musicians are creative, then:', options: ['All programmers are creative', 'Some programmers are creative', 'No programmers are creative', 'All creative people are programmers'], correctAnswer: 1, explanation: 'Some programmers who are musicians are creative.', difficulty: 'hard' },
      { id: 'l7', question: 'Which is the odd one out? Apple, Banana, Carrot, Grape', options: ['Apple', 'Banana', 'Carrot', 'Grape'], correctAnswer: 2, explanation: 'Carrot is a vegetable; the others are fruits.', difficulty: 'easy' },
      { id: 'l8', question: 'Continue: Z, Y, X, W, __', options: ['U', 'V', 'T', 'S'], correctAnswer: 1, explanation: 'Alphabet backwards: after W comes V.', difficulty: 'easy' },
      { id: 'l9', question: 'If today is Tuesday, what day is 100 days from now?', options: ['Wednesday', 'Thursday', 'Friday', 'Saturday'], correctAnswer: 1, explanation: '100 mod 7 = 2 days after Tuesday = Thursday.', difficulty: 'hard' },
      { id: 'l10', question: 'Find next: 1, 4, 9, 16, 25, __', options: ['30', '36', '42', '49'], correctAnswer: 1, explanation: 'Perfect squares: 1², 2², 3², 4², 5², 6² = 36.', difficulty: 'medium' },
    ],
  },
  {
    id: 'vocab',
    title: 'English Vocabulary',
    category: 'English',
    icon: '📚',
    color: 'from-emerald-500 to-green-500',
    description: 'Expand your vocabulary!',
    questions: [
      { id: 'v1', question: 'What does "benevolent" mean?', options: ['Mean', 'Kind', 'Lazy', 'Angry'], correctAnswer: 1, explanation: 'Benevolent means well-meaning and kindly.', difficulty: 'medium' },
      { id: 'v2', question: 'Synonym of "rapid"?', options: ['Slow', 'Fast', 'Heavy', 'Soft'], correctAnswer: 1, explanation: 'Rapid means happening quickly, same as fast.', difficulty: 'easy' },
      { id: 'v3', question: 'Antonym of "ancient"?', options: ['Old', 'Modern', 'Historic', 'Vintage'], correctAnswer: 1, explanation: 'Modern is the opposite of ancient.', difficulty: 'easy' },
      { id: 'v4', question: 'What does "ubiquitous" mean?', options: ['Rare', 'Everywhere', 'Unique', 'Hidden'], correctAnswer: 1, explanation: 'Ubiquitous means present everywhere.', difficulty: 'hard' },
      { id: 'v5', question: 'Which means "to make better"?', options: ['Worsen', 'Improve', 'Ignore', 'Damage'], correctAnswer: 1, explanation: 'Improve means to make something better.', difficulty: 'easy' },
      { id: 'v6', question: 'What is a "philanthropist"?', options: ['A scientist', 'A charitable person', 'A philosopher', 'A photographer'], correctAnswer: 1, explanation: 'A philanthropist donates to charitable causes.', difficulty: 'medium' },
      { id: 'v7', question: 'Synonym of "ephemeral"?', options: ['Permanent', 'Temporary', 'Strong', 'Large'], correctAnswer: 1, explanation: 'Ephemeral means lasting a very short time.', difficulty: 'hard' },
      { id: 'v8', question: 'What does "procrastinate" mean?', options: ['Finish quickly', 'Delay tasks', 'Celebrate', 'Argue'], correctAnswer: 1, explanation: 'To procrastinate is to delay or postpone tasks.', difficulty: 'medium' },
      { id: 'v9', question: 'Which word means "fear of heights"?', options: ['Claustrophobia', 'Acrophobia', 'Agoraphobia', 'Hydrophobia'], correctAnswer: 1, explanation: 'Acrophobia is the fear of heights.', difficulty: 'medium' },
      { id: 'v10', question: 'What does "meticulous" mean?', options: ['Careless', 'Very careful', 'Average', 'Quick'], correctAnswer: 1, explanation: 'Meticulous means showing great attention to detail.', difficulty: 'medium' },
    ],
  },
  {
    id: 'funfacts',
    title: 'Fun Facts',
    category: 'Fun',
    icon: '🎉',
    color: 'from-fuchsia-500 to-purple-500',
    description: 'Learn amazing fun facts!',
    questions: [
      { id: 'f1', question: 'How many hearts does an octopus have?', options: ['1', '2', '3', '4'], correctAnswer: 2, explanation: 'Octopuses have 3 hearts: two pump blood to gills, one to the body.', difficulty: 'medium' },
      { id: 'f2', question: 'Which animal has the longest lifespan?', options: ['Elephant', 'Giant tortoise', 'Whale', 'Parrot'], correctAnswer: 1, explanation: 'Giant tortoises can live over 150 years.', difficulty: 'easy' },
      { id: 'f3', question: 'What is the most spoken language in the world?', options: ['English', 'Mandarin Chinese', 'Spanish', 'Hindi'], correctAnswer: 1, explanation: 'Mandarin Chinese has the most native speakers.', difficulty: 'easy' },
      { id: 'f4', question: 'How many bones are in an adult human body?', options: ['186', '206', '226', '246'], correctAnswer: 1, explanation: 'Adults have 206 bones; babies have about 270.', difficulty: 'medium' },
      { id: 'f5', question: 'Which fruit has seeds on the outside?', options: ['Apple', 'Strawberry', 'Banana', 'Grape'], correctAnswer: 1, explanation: 'Strawberries are the only fruit with seeds on the outside.', difficulty: 'easy' },
      { id: 'f6', question: 'How many time zones does Russia have?', options: ['7', '9', '11', '13'], correctAnswer: 2, explanation: 'Russia spans 11 time zones, the most of any country.', difficulty: 'hard' },
      { id: 'f7', question: 'Which bird can fly backwards?', options: ['Eagle', 'Hummingbird', 'Parrot', 'Owl'], correctAnswer: 1, explanation: 'Hummingbirds are the only birds that can fly backwards.', difficulty: 'easy' },
      { id: 'f8', question: 'What percentage of the Earth is covered by water?', options: ['50%', '60%', '70%', '80%'], correctAnswer: 2, explanation: 'About 71% of Earth\'s surface is water.', difficulty: 'easy' },
      { id: 'f9', question: 'Which planet spins backwards?', options: ['Mars', 'Venus', 'Jupiter', 'Saturn'], correctAnswer: 1, explanation: 'Venus rotates clockwise (retrograde), opposite to most planets.', difficulty: 'hard' },
      { id: 'f10', question: 'How many colors are in a rainbow?', options: ['5', '6', '7', '8'], correctAnswer: 2, explanation: '7 colors: red, orange, yellow, green, blue, indigo, violet.', difficulty: 'easy' },
    ],
  },
];

// Daily challenges data
export interface DailyChallenge {
  id: string;
  category: string;
  difficulty: 'easy' | 'medium' | 'hard';
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
  rewardPoints: number;
  icon: string;
}

export const dailyChallenges: DailyChallenge[] = [
  { id: 'dc1', category: 'Logic', difficulty: 'medium', question: 'What is the next number: 3, 6, 12, 24, __?', options: ['30', '36', '48', '60'], correctAnswer: 2, explanation: 'Each number is doubled: 24 × 2 = 48.', rewardPoints: 50, icon: '🧠' },
  { id: 'dc2', category: 'Math', difficulty: 'easy', question: 'If you have 3 apples and give away 1, then buy 5 more, how many do you have?', options: ['6', '7', '8', '9'], correctAnswer: 1, explanation: '3 - 1 + 5 = 7 apples.', rewardPoints: 30, icon: '🍎' },
  { id: 'dc3', category: 'Science', difficulty: 'medium', question: 'What element has the symbol "Fe"?', options: ['Fluorine', 'Iron', 'Francium', 'Fermium'], correctAnswer: 1, explanation: 'Fe comes from "ferrum", the Latin word for iron.', rewardPoints: 40, icon: '⚗️' },
  { id: 'dc4', category: 'Puzzle', difficulty: 'hard', question: 'I speak without a mouth and hear without ears. I have no body, but I come alive with the wind. What am I?', options: ['A ghost', 'An echo', 'A shadow', 'A cloud'], correctAnswer: 1, explanation: 'An echo speaks back and comes alive with sound (wind carries it).', rewardPoints: 60, icon: '🔮' },
  { id: 'dc5', category: 'Logic', difficulty: 'easy', question: 'Find the odd one out: Dog, Cat, Fish, Cow', options: ['Dog', 'Cat', 'Fish', 'Cow'], correctAnswer: 2, explanation: 'Fish lives in water; the others are land mammals.', rewardPoints: 30, icon: '🐟' },
  { id: 'dc6', category: 'Coding', difficulty: 'medium', question: 'What is the output of: print(len("Hello") + len("World"))?', options: ['9', '10', '11', 'Error'], correctAnswer: 1, explanation: 'len("Hello") = 5, len("World") = 5, total = 10.', rewardPoints: 45, icon: '💻' },
  { id: 'dc7', category: 'Math', difficulty: 'hard', question: 'What is the sum of numbers from 1 to 100?', options: ['5000', '5050', '5100', '5150'], correctAnswer: 1, explanation: 'Using formula n(n+1)/2: 100 × 101 / 2 = 5050.', rewardPoints: 60, icon: '🔢' },
  { id: 'dc8', category: 'Word', difficulty: 'medium', question: 'Unscramble: "EARNL" to form a learning-related word', options: ['LEARN', 'ALERT', 'LATER', 'ALTER'], correctAnswer: 0, explanation: 'LEARN is related to learning.', rewardPoints: 40, icon: '📖' },
  { id: 'dc9', category: 'Science', difficulty: 'easy', question: 'What do bees collect from flowers?', options: ['Water', 'Nectar', 'Leaves', 'Seeds'], correctAnswer: 1, explanation: 'Bees collect nectar to make honey.', rewardPoints: 25, icon: '🐝' },
  { id: 'dc10', category: 'Logic', difficulty: 'medium', question: 'Complete: 1, 3, 6, 10, 15, __', options: ['18', '20', '21', '25'], correctAnswer: 2, explanation: 'Triangular numbers: +2, +3, +4, +5, +6 = 21.', rewardPoints: 45, icon: '📐' },
  { id: 'dc11', category: 'Fun', difficulty: 'easy', question: 'Which is the largest mammal on Earth?', options: ['Elephant', 'Blue whale', 'Giraffe', 'Hippo'], correctAnswer: 1, explanation: 'Blue whales can grow up to 100 feet long.', rewardPoints: 25, icon: '🐋' },
  { id: 'dc12', category: 'Puzzle', difficulty: 'hard', question: 'If 5 machines make 5 widgets in 5 minutes, how long for 100 machines to make 100 widgets?', options: ['100 minutes', '5 minutes', '20 minutes', '1 minute'], correctAnswer: 1, explanation: 'Each machine makes 1 widget in 5 min, so 100 machines make 100 widgets in 5 min.', rewardPoints: 70, icon: '⚙️' },
  { id: 'dc13', category: 'Word', difficulty: 'medium', question: 'Which word does NOT belong? Cat, Dog, Carrot, Rabbit', options: ['Cat', 'Dog', 'Carrot', 'Rabbit'], correctAnswer: 2, explanation: 'Carrot is a vegetable; the others are animals.', rewardPoints: 35, icon: '🥕' },
  { id: 'dc14', category: 'Math', difficulty: 'medium', question: 'What is 25% of 80?', options: ['15', '20', '25', '30'], correctAnswer: 1, explanation: '25% × 80 = 0.25 × 80 = 20.', rewardPoints: 35, icon: '📊' },
  { id: 'dc15', category: 'Coding', difficulty: 'easy', question: 'Which symbol is used for comments in Python?', options: ['//', '#', '/*', '--'], correctAnswer: 1, explanation: 'Python uses # for single-line comments.', rewardPoints: 25, icon: '🐍' },
  { id: 'dc16', category: 'Logic', difficulty: 'hard', question: 'A farmer has 17 sheep. All but 9 die. How many are left?', options: ['8', '9', '17', '0'], correctAnswer: 1, explanation: '"All but 9" means 9 survive.', rewardPoints: 55, icon: '🐑' },
  { id: 'dc17', category: 'Science', difficulty: 'medium', question: 'What gas do humans exhale the most?', options: ['Oxygen', 'Carbon dioxide', 'Nitrogen', 'Hydrogen'], correctAnswer: 2, explanation: 'We exhale mostly nitrogen (~78%), then CO2 (~4%).', rewardPoints: 50, icon: '💨' },
  { id: 'dc18', category: 'Puzzle', difficulty: 'medium', question: 'What has keys but no locks, space but no room, and you can enter but not go inside?', options: ['A house', 'A keyboard', 'A map', 'A book'], correctAnswer: 1, explanation: 'A keyboard has keys, spacebar, and Enter key.', rewardPoints: 45, icon: '⌨️' },
  { id: 'dc19', category: 'Word', difficulty: 'hard', question: 'Which word means "a fear of long words"?', options: ['Logophobia', 'Hippopotomonstrosesquippedaliophobia', 'Bibliophobia', 'Lexicophobia'], correctAnswer: 1, explanation: 'Ironically, the fear of long words has a very long name!', rewardPoints: 65, icon: '📝' },
  { id: 'dc20', category: 'Math', difficulty: 'easy', question: 'What is 9 × 9?', options: ['72', '81', '89', '99'], correctAnswer: 1, explanation: '9 × 9 = 81.', rewardPoints: 25, icon: '✨' },
  { id: 'dc21', category: 'Fun', difficulty: 'medium', question: 'How many legs does a spider have?', options: ['6', '8', '10', '12'], correctAnswer: 1, explanation: 'Spiders are arachnids with 8 legs.', rewardPoints: 30, icon: '🕷️' },
  { id: 'dc22', category: 'Logic', difficulty: 'easy', question: 'If it takes 5 minutes to boil 1 egg, how long to boil 3 eggs together?', options: ['15 min', '5 min', '10 min', '3 min'], correctAnswer: 1, explanation: 'They boil together in the same time: 5 minutes.', rewardPoints: 30, icon: '🥚' },
  { id: 'dc23', category: 'Science', difficulty: 'hard', question: 'What is the chemical formula for table salt?', options: ['NaCl', 'KCl', 'CaCl₂', 'NaOH'], correctAnswer: 0, explanation: 'NaCl = Sodium Chloride = table salt.', rewardPoints: 50, icon: '🧂' },
  { id: 'dc24', category: 'Puzzle', difficulty: 'easy', question: 'What has hands but cannot clap?', options: ['A tree', 'A clock', 'A glove', 'A statue'], correctAnswer: 1, explanation: 'A clock has hands that show time.', rewardPoints: 25, icon: '⏰' },
  { id: 'dc25', category: 'Coding', difficulty: 'medium', question: 'What does "===" mean in JavaScript?', options: ['Assignment', 'Loose equality', 'Strict equality', 'Inequality'], correctAnswer: 2, explanation: '=== checks both value and type equality.', rewardPoints: 40, icon: '📜' },
  { id: 'dc26', category: 'Word', difficulty: 'easy', question: 'Unscramble: "ATC" to get a pet animal', options: ['CAT', 'ACT', 'TAC', 'CTA'], correctAnswer: 0, explanation: 'CAT is a common pet.', rewardPoints: 20, icon: '🐱' },
  { id: 'dc27', category: 'Logic', difficulty: 'medium', question: 'What is 2 + 2 × 2?', options: ['8', '6', '4', '10'], correctAnswer: 1, explanation: 'Multiplication first: 2 + (2×2) = 2 + 4 = 6.', rewardPoints: 35, icon: '➕' },
  { id: 'dc28', category: 'Fun', difficulty: 'medium', question: 'Which country invented pizza?', options: ['France', 'Greece', 'Italy', 'Spain'], correctAnswer: 2, explanation: 'Modern pizza originated in Naples, Italy.', rewardPoints: 30, icon: '🍕' },
  { id: 'dc29', category: 'Science', difficulty: 'easy', question: 'How many planets are in our solar system?', options: ['7', '8', '9', '10'], correctAnswer: 1, explanation: 'There are 8 planets since Pluto was reclassified in 2006.', rewardPoints: 25, icon: '🪐' },
  { id: 'dc30', category: 'Math', difficulty: 'hard', question: 'What is the next prime after 23?', options: ['24', '25', '27', '29'], correctAnswer: 3, explanation: '24, 25, 27 are composite; 29 is prime.', rewardPoints: 45, icon: '🎯' },
  { id: 'dc31', category: 'Puzzle', difficulty: 'medium', question: 'I have cities but no houses, forests but no trees, water but no fish. What am I?', options: ['A dream', 'A map', 'A painting', 'A story'], correctAnswer: 1, explanation: 'A map shows these things but doesn\'t contain them.', rewardPoints: 45, icon: '🗺️' },
];

// Riddles data
export interface Riddle {
  id: string;
  riddle: string;
  answer: string;
  hints: string[];
  explanation: string;
  difficulty: 'easy' | 'medium' | 'hard';
}

export const riddles: Riddle[] = [
  { id: 'r1', riddle: 'I have keys but no locks. I have space but no room. You can enter but not go inside. What am I?', answer: 'keyboard', hints: ['It\'s on your desk', 'You use it with a computer', 'It has letters and numbers'], explanation: 'A keyboard has keys, spacebar, and Enter key.', difficulty: 'medium' },
  { id: 'r2', riddle: 'What has a head, a tail, is brown, and has no legs?', answer: 'penny', hints: ['It\'s money', 'It\'s a coin', 'Features Abraham Lincoln'], explanation: 'A penny has a head side and tail side, is brown copper, and has no legs.', difficulty: 'medium' },
  { id: 'r3', riddle: 'What gets wetter the more it dries?', answer: 'towel', hints: ['You use it in the bathroom', 'After a shower', 'Made of cloth'], explanation: 'A towel absorbs water from you, getting wetter while drying you.', difficulty: 'easy' },
  { id: 'r4', riddle: 'What has many teeth but cannot bite?', answer: 'comb', hints: ['Used on hair', 'Made of plastic usually', 'Helps with styling'], explanation: 'A comb has teeth but can\'t bite like an animal.', difficulty: 'easy' },
  { id: 'r5', riddle: 'The more you take, the more you leave behind. What am I?', answer: 'footsteps', hints: ['Think about walking', 'You leave marks', 'On sand or snow'], explanation: 'Every step you take leaves a footprint behind.', difficulty: 'medium' },
  { id: 'r6', riddle: 'What has a neck but no head?', answer: 'bottle', hints: ['Holds liquids', 'Used for drinks', 'Has a cap'], explanation: 'A bottle has a narrow neck but no head.', difficulty: 'easy' },
  { id: 'r7', riddle: 'What can travel around the world while staying in a corner?', answer: 'stamp', hints: ['On envelopes', 'Small and adhesive', 'Used for mail'], explanation: 'A stamp on an envelope travels the world but stays in the corner.', difficulty: 'hard' },
  { id: 'r8', riddle: 'What has to be broken before you can use it?', answer: 'egg', hints: ['From a chicken', 'Used in cooking', 'Has a shell'], explanation: 'You must break an egg\'s shell to use it.', difficulty: 'easy' },
  { id: 'r9', riddle: 'I am tall when I\'m young and short when I\'m old. What am I?', answer: 'candle', hints: ['Gives light', 'Has a flame', 'Made of wax'], explanation: 'A candle burns down, getting shorter as it ages.', difficulty: 'medium' },
  { id: 'r10', riddle: 'What month of the year has 28 days?', answer: 'all of them', hints: ['Not just one', 'Think carefully', 'Every month has...'], explanation: 'All months have at least 28 days!', difficulty: 'medium' },
  { id: 'r11', riddle: 'What is full of holes but still holds water?', answer: 'sponge', hints: ['Used for cleaning', 'Absorbs liquid', 'In your kitchen'], explanation: 'A sponge has many holes but holds water in them.', difficulty: 'easy' },
  { id: 'r12', riddle: 'What question can you never answer yes to?', answer: 'are you asleep', hints: ['State of consciousness', 'Nighttime activity', 'If you answer...'], explanation: 'If you\'re asleep, you can\'t answer at all!', difficulty: 'hard' },
  { id: 'r13', riddle: 'What has hands but can\'t clap?', answer: 'clock', hints: ['Tells time', 'On the wall', 'Has numbers'], explanation: 'A clock has hands (hour and minute) but can\'t clap.', difficulty: 'easy' },
  { id: 'r14', riddle: 'What has words but never speaks?', answer: 'book', hints: ['You read it', 'Made of paper', 'Found in libraries'], explanation: 'A book contains words but cannot speak them.', difficulty: 'easy' },
  { id: 'r15', riddle: 'What can you hold in your right hand but never in your left?', answer: 'your left hand', hints: ['Part of your body', 'Try it yourself', 'Physical impossibility'], explanation: 'You can\'t hold your left hand in your left hand!', difficulty: 'hard' },
];

// Logic puzzles data
export interface Puzzle {
  id: string;
  type: 'sequence' | 'oddout' | 'pattern' | 'riddle' | 'math';
  title: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
  difficulty: 'easy' | 'medium' | 'hard';
  hint: string;
  rewardPoints: number;
}

export const puzzles: Puzzle[] = [
  { id: 'pu1', type: 'sequence', title: 'Number Sequence', question: 'What comes next? 2, 4, 8, 16, 32, __', options: ['48', '64', '60', '40'], correctAnswer: 1, explanation: 'Each number doubles: 32 × 2 = 64.', difficulty: 'easy', hint: 'Each number is multiplied by the same value.', rewardPoints: 20 },
  { id: 'pu2', type: 'sequence', title: 'Fibonacci', question: 'What comes next? 1, 1, 2, 3, 5, 8, __', options: ['11', '12', '13', '14'], correctAnswer: 2, explanation: 'Add previous two numbers: 5 + 8 = 13.', difficulty: 'medium', hint: 'Each number is the sum of the two before it.', rewardPoints: 30 },
  { id: 'pu3', type: 'oddout', title: 'Odd One Out', question: 'Which doesn\'t belong? Apple, Banana, Carrot, Orange, Grape', options: ['Apple', 'Banana', 'Carrot', 'Orange'], correctAnswer: 2, explanation: 'Carrot is a vegetable; others are fruits.', difficulty: 'easy', hint: 'Think about food categories.', rewardPoints: 15 },
  { id: 'pu4', type: 'pattern', title: 'Shape Pattern', question: '△ ○ △ ○ △ ○ __', options: ['△', '○', '□', '◇'], correctAnswer: 0, explanation: 'The pattern alternates: triangle, circle, triangle, circle...', difficulty: 'easy', hint: 'Look at the alternating pattern.', rewardPoints: 15 },
  { id: 'pu5', type: 'math', title: 'Missing Number', question: 'If 3x + 5 = 20, what is x?', options: ['3', '4', '5', '6'], correctAnswer: 2, explanation: '3x = 20 - 5 = 15, so x = 5.', difficulty: 'medium', hint: 'Subtract 5 from both sides, then divide by 3.', rewardPoints: 25 },
  { id: 'pu6', type: 'sequence', title: 'Square Numbers', question: 'Complete: 1, 4, 9, 16, 25, __', options: ['30', '36', '49', '42'], correctAnswer: 1, explanation: 'These are perfect squares: 1², 2², 3², 4², 5², 6²=36.', difficulty: 'medium', hint: 'Think about perfect squares.', rewardPoints: 30 },
  { id: 'pu7', type: 'oddout', title: 'Number Odd One', question: 'Which is odd? 2, 4, 6, 9, 10', options: ['2', '4', '9', '10'], correctAnswer: 2, explanation: '9 is odd; the others are even numbers.', difficulty: 'easy', hint: 'Consider even and odd numbers.', rewardPoints: 15 },
  { id: 'pu8', type: 'riddle', title: 'Logic Riddle', question: 'A father and son are in a car crash. The father dies. The son is rushed to surgery. The surgeon says "I can\'t operate, he\'s my son!" How?', options: ['The surgeon is lying', 'The surgeon is the mother', 'It\'s a ghost', 'Impossible'], correctAnswer: 1, explanation: 'The surgeon is the boy\'s mother.', difficulty: 'medium', hint: 'Challenge your assumptions about gender.', rewardPoints: 35 },
  { id: 'pu9', type: 'sequence', title: 'Primes', question: 'Next prime after 13: 2, 3, 5, 7, 11, 13, __', options: ['14', '15', '16', '17'], correctAnswer: 3, explanation: '17 is the next prime after 13.', difficulty: 'medium', hint: 'A prime has only two factors: 1 and itself.', rewardPoints: 25 },
  { id: 'pu10', type: 'math', title: 'Age Problem', question: 'If Sara is twice as old as Tom, and Tom is 10, how old is Sara?', options: ['15', '20', '25', '30'], correctAnswer: 1, explanation: 'Sara = 2 × Tom = 2 × 10 = 20.', difficulty: 'easy', hint: 'Simple multiplication.', rewardPoints: 20 },
  { id: 'pu11', type: 'pattern', title: 'Letter Pattern', question: 'A, C, E, G, __', options: ['H', 'I', 'J', 'K'], correctAnswer: 1, explanation: 'Skip one letter: A(C) skip B, C(E) skip D, etc. Next is I.', difficulty: 'medium', hint: 'Skip one letter each time.', rewardPoints: 25 },
  { id: 'pu12', type: 'oddout', title: 'Animal Odd One', question: 'Which is different? Cat, Dog, Fish, Horse', options: ['Cat', 'Dog', 'Fish', 'Horse'], correctAnswer: 2, explanation: 'Fish lives in water; others are land mammals.', difficulty: 'easy', hint: 'Think about where they live.', rewardPoints: 15 },
  { id: 'pu13', type: 'sequence', title: 'Cube Numbers', question: '1, 8, 27, 64, __', options: ['100', '125', '128', '144'], correctAnswer: 1, explanation: 'Cubes: 1³, 2³, 3³, 4³, 5³ = 125.', difficulty: 'hard', hint: 'Think about cubed numbers.', rewardPoints: 40 },
  { id: 'pu14', type: 'riddle', title: 'Mystery Object', question: 'I have a face but no eyes, hands but no arms. What am I?', options: ['A clock', 'A doll', 'A mask', 'A photo'], correctAnswer: 0, explanation: 'A clock has a face and hands (hour/minute) but no eyes or arms.', difficulty: 'medium', hint: 'It tells time.', rewardPoints: 30 },
  { id: 'pu15', type: 'math', title: 'Speed Problem', question: 'A car travels 60 miles in 1 hour. How far in 3 hours?', options: ['120', '150', '180', '200'], correctAnswer: 2, explanation: '60 × 3 = 180 miles.', difficulty: 'easy', hint: 'Multiply speed by time.', rewardPoints: 20 },
];

// Word scramble data
export interface WordGame {
  id: string;
  scrambled: string;
  answer: string;
  hint: string;
  category: string;
}

export const wordGames: WordGame[] = [
  { id: 'w1', scrambled: 'PYTAPE', answer: 'PAPAYA', hint: 'A tropical fruit', category: 'Fruits' },
  { id: 'w2', scrambled: 'ONOLCD', answer: 'LONDON', hint: 'A capital city', category: 'Cities' },
  { id: 'w3', scrambled: 'THGIL', answer: 'LIGHT', hint: 'Opposite of dark', category: 'Words' },
  { id: 'w4', scrambled: 'YRSTDO', answer: 'STORY', hint: 'Something you read or tell', category: 'Words' },
  { id: 'w5', scrambled: 'NAABAN', answer: 'BANANA', hint: 'A yellow fruit', category: 'Fruits' },
  { id: 'w6', scrambled: 'NAPLAET', answer: 'PLANET', hint: 'Earth is one', category: 'Space' },
  { id: 'w7', scrambled: 'CUMIS', answer: 'MUSIC', hint: 'You listen to this', category: 'Arts' },
  { id: 'w8', scrambled: 'RETNWI', answer: 'WINTER', hint: 'A cold season', category: 'Seasons' },
  { id: 'w9', scrambled: 'OOCBK', answer: 'BOOK', hint: 'You read this', category: 'Objects' },
  { id: 'w10', scrambled: 'ELPAP', answer: 'APPLE', hint: 'A common fruit', category: 'Fruits' },
  { id: 'w11', scrambled: 'DRAEC', answer: 'CARED', hint: 'Past tense of care', category: 'Words' },
  { id: 'w12', scrambled: 'TAEGR', answer: 'GREAT', hint: 'Very good', category: 'Words' },
];

// Affirmations
export const affirmations = [
  "You are capable of amazing things! 🌟",
  "Every challenge is an opportunity to grow! 🌱",
  "Believe in yourself - you've got this! 💪",
  "Your potential is limitless! 🚀",
  "Take a deep breath. You are enough. 🧘",
  "Progress, not perfection. Keep going! ⭐",
  "You're stronger than you think! 🦁",
  "Small steps lead to big achievements! 👣",
  "Be proud of how far you've come! 🏆",
  "Your effort today shapes your tomorrow! 🌅",
  "Learning is a journey, not a race! 🛤️",
  "You inspire others with your dedication! ✨",
  "Rest is productive too. Take care! 🌸",
  "Your curiosity is your superpower! 🦸",
  "Mistakes are just lessons in disguise! 📚",
];

// Motivational messages
export const motivationalMessages = [
  "Your brain deserves a little fun! 🎉",
  "Think smart, play smart, grow every day! 🧠",
  "Every puzzle makes you a better problem solver! 🧩",
  "Mistakes are proof that you're trying! ✨",
  "Refresh your mind. Refocus your goals. 🎯",
  "You're capable of more than you think! 💫",
  "Learn a little. Laugh a little. Grow a lot! 🌱",
  "Small breaks, big comebacks! 🚀",
  "Your brain is getting stronger with every challenge! 💪",
  "Take a moment. Breathe. Then conquer! 🌟",
];
